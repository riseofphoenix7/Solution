import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MeetScheduler extends StatefulWidget {
  final String targetUser; // The user you're scheduling a meeting with

  const MeetScheduler({super.key, required this.targetUser});

  @override
  _MeetSchedulerState createState() => _MeetSchedulerState();
}

class _MeetSchedulerState extends State<MeetScheduler> {
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String currentUserId = '';

  @override
  void initState() {
    super.initState();
    _getCurrentUserId();
  }

  Future<void> _getCurrentUserId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        currentUserId = user.uid;
      });
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked =
        await showTimePicker(context: context, initialTime: TimeOfDay.now());
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _scheduleMeeting() async {
    if (_selectedDate != null && _selectedTime != null) {
      // Format the selected date and time
      DateTime meetingDateTime = DateTime(
        _selectedDate!.year,
        _selectedDate!.month,
        _selectedDate!.day,
        _selectedTime!.hour,
        _selectedTime!.minute,
      );

      // Save the meeting details to Firestore
      await FirebaseFirestore.instance.collection('meetings').add({
        'initiator': currentUserId,
        'targetUser': widget.targetUser,
        'time': meetingDateTime.toIso8601String(),
        'confirmed': false, // Meeting is unconfirmed by default
      });

      // Optionally, show a success message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Meeting scheduled successfully!')),
      );
    } else {
      // Show an error if date or time is not selected
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select both date and time.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Schedule a Meeting with ${widget.targetUser}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Select a Date:'),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () => _selectDate(context),
              child: Text(_selectedDate == null
                  ? 'Choose Date'
                  : '${_selectedDate!.toLocal()}'.split(' ')[0]),
            ),
            const SizedBox(height: 16),
            const Text('Select a Time:'),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () => _selectTime(context),
              child: Text(_selectedTime == null
                  ? 'Choose Time'
                  : _selectedTime!.format(context)),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _scheduleMeeting,
              child: const Text('Schedule Meeting'),
            ),
          ],
        ),
      ),
    );
  }
}
