import 'package:flutter/material.dart';

class InternshipListingsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> internships = [
    {
      'title': 'Software Development Intern',
      'company': 'TechCorp',
      'description': 'Assist in developing and maintaining web applications using React and Node.js.',
      'salary': '\$20k/permonth',
      'email': 'careers@techcorp.com',
      'phone': '+1 (555) 123-4567',
      'website': 'https://www.techcorp.com',
    },
    {
      'title': 'Design for rural SMES',
      'company': 'Jyothi works',
      'description': 'Work on machine learning models and data analysis projects.',
      'salary': '\$10k',
      'email': 'hr@datatech.com',
      'phone': '+1 (555) 987-6543',
      'website': 'https://www.datatech.com',
    },
    {
      'title': 'UI/UX Design Intern',
      'company': 'DesignHub',
      'description': 'Create user-centric designs for web and mobile applications.',
      'salary': '\$18/hour',
      'email': 'interns@designhub.com',
      'phone': '+1 (555) 246-8101',
      'website': 'https://www.designhub.com',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: internships.length,
      itemBuilder: (context, index) {
        return InternshipCard(internship: internships[index]);
      },
    );
  }
}

class InternshipCard extends StatelessWidget {
  final Map<String, dynamic> internship;

  const InternshipCard({Key? key, required this.internship}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: InkWell(
        onTap: () => _showDetailsDialog(context),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                internship['title'],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 4),
              Text(
                internship['company'],
                style: TextStyle(fontSize: 16, color: Colors.grey[600]),
              ),
              SizedBox(height: 8),
              Text(
                internship['description'],
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Salary: ${internship['salary']}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.email, color: Colors.blue),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.language, color: Colors.green),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.phone, color: Colors.red),
                        onPressed: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showDetailsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(internship['title']),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Company: ${internship['company']}'),
                SizedBox(height: 8),
                Text('Description: ${internship['description']}'),
                SizedBox(height: 8),
                Text('Salary: ${internship['salary']}'),
                SizedBox(height: 8),
                Text('Email: ${internship['email']}'),
                SizedBox(height: 8),
                Text('Phone: ${internship['phone']}'),
                SizedBox(height: 8),
                Text('Website: ${internship['website']}'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Close'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}