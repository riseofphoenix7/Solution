import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mitra/forumscreens/forumfeed.dart';
import "package:mitra/jitsimeet/jitsimeet.dart";
import "package:mitra/jitsimeet/meetscheduler.dart";
import "package:mitra/jitsimeet/meetings.dart";
import 'package:mitra/SmeScreens/SmeChatbot.dart';
import 'package:mitra/forumscreens/topicpage.dart';
import 'profile_screen.dart';
import 'search_screen.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  _LandingpageState createState() => _LandingpageState();
}

class _LandingpageState extends State<LandingScreen> {
  int _selectedIndex = 0;
  String userName = 'Investor';

  @override
  void initState() {
    super.initState();
    _getUserName(); // Fetch the username on init
  }

  Future<void> _getUserName() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('investors')
            .doc(user.uid)
            .get();
        if (userDoc.exists && userDoc['name'] != null) {
          setState(() {
            userName = userDoc['name'];
          });
        } else {
          setState(() {
            userName = user.displayName ?? 'Investor';
          });
        }
      } catch (e) {
        setState(() {
          userName = user.displayName ?? 'Investor';
        });
      }
    }
  }

  final List<Widget> _widgetOptions = [
    const LandingpageContent(),
    const Smechatbot(),
    const MeetingsPage(),
    const ForumTopicsPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.account_balance, color: Colors.white),
            SizedBox(width: 7),
            Text(
              'MITRA',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.account_circle),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const ProfileScreen()),
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              /*
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MeetScheduler(targetUser: userName), // Replace with userName
                ),*/

              Navigator.push(
                /*
                builder: (context) =>
                        JitsiMeetScreen(title: 'Join a Meeting')),
                */
                context,
                MaterialPageRoute(
                  builder: (context) => MeetingsPage(),
                  // Replace with userName
                ),
              ); // Navigate to Notifications
            },
          ),
        ],
        backgroundColor: const Color.fromARGB(255, 41, 169, 154),
        //backgroundColor: const Color.fromARGB(255, 41, 169, 154),
      ),
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Main Menu',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'ChatBot',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.video_call),
            label: 'Meetings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.forum),
            label: 'Forums',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.teal[700],
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}

class LandingpageContent extends StatelessWidget {
  const LandingpageContent({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const SizedBox(height: 16),
            _buildSearchBar(context),
            const SizedBox(height: 24),
            _buildMainFeatures(context),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

Widget _buildHeader(BuildContext context) {
  _LandingpageState landingPageState =
      context.findAncestorStateOfType<_LandingpageState>()!;
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Hello ${landingPageState.userName}',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF003366),
            ),
          ),
          const Text(
            'Ready to invest?',
            style: TextStyle(
              color: Colors.blueGrey,
              fontSize: 16,
            ),
          ),
        ],
      ),
      const CircleAvatar(
        radius: 20,
        backgroundColor: Colors.blueGrey,
      ),
    ],
  );
}

Widget _buildSearchBar(BuildContext context) {
  TextEditingController searchController = TextEditingController();

  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(8),
      boxShadow: [
        BoxShadow(
          color: Colors.blueGrey.withOpacity(0.1),
          blurRadius: 10,
          offset: const Offset(0, 5),
        ),
      ],
    ),
    child: TextField(
      controller: searchController,
      decoration: InputDecoration(
        icon: const Icon(Icons.search, color: Colors.blueGrey),
        hintText: 'Look For Businesses',
        border: InputBorder.none,
        hintStyle: TextStyle(color: Colors.blueGrey[300]),
      ),
      onSubmitted: (query) {
        if (query.isNotEmpty) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SearchResultScreen(searchTerm: query),
            ),
          );
        }
      },
    ),
  );
}

Widget _buildMainFeatures(BuildContext context) {
  final features = [
    {
      'icon': Icons.dashboard,
      'title': 'Create A Dashboard',
      'color': Colors.teal,
      'route': '/dashboard'
    },
    {
      'icon': Icons.show_chart,
      'title': 'Latest Financial News',
      'title': 'Latest Financial News',
      'color': Colors.indigo,
      'route': '/news'
    },
    {
      'icon': Icons.feed,
      'title': 'Find Businesses',
      'color': Colors.deepOrange,
      'route': '/find-investors'
    },
    {
      'icon': Icons.group,
      'title': 'Explore Various Communities',
      'color': Colors.deepPurple,
      'route': '/forums'
    },
  ];

  return GridView.builder(
    shrinkWrap: true,
    physics: const NeverScrollableScrollPhysics(),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.2,
    ),
    itemCount: features.length,
    itemBuilder: (context, index) {
      final feature = features[index];
      return GestureDetector(
        onTap: () => _navigateToPage(context, feature['route'] as String),
        child: Container(
          decoration: BoxDecoration(
            color: feature['color'] as Color,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    feature['icon'] as IconData,
                    color: Colors.white,
                  ),
                ),
                Text(
                  feature['title'] as String,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}

void _navigateToPage(BuildContext context, String route) {
  Navigator.pushNamed(context, route);
}