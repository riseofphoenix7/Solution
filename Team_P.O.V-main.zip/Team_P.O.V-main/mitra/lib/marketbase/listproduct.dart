import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class BuyingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Available Products')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('products').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Something went wrong'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          return GridView.builder(
            padding: EdgeInsets.all(16.0),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.75,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var product = snapshot.data!.docs[index];
              return ProductCard(
                name: product['name'],
                price: product['price'].toDouble(),
                imageUrl: product['imageUrl'],
                onTap: () => _showProductDetails(context, product),
              );
            },
          );
        },
      ),
    );
  }

  void _showProductDetails(BuildContext context, DocumentSnapshot product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(product['name'], style: Theme.of(context).textTheme.headlineSmall),
            SizedBox(height: 8),
            Text('\$${product['price'].toStringAsFixed(2)}', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text(product['description']),
            SizedBox(height: 8),
            Text('Category: ${product['category']}'),
            SizedBox(height: 8),
            Text('Quantity: ${product['quantity']}'),
            SizedBox(height: 8),
            Text('Features:', style: TextStyle(fontWeight: FontWeight.bold)),
            ...List<Widget>.from(product['features'].map((feature) => Text('• $feature'))),
            SizedBox(height: 16),
            ElevatedButton(
              child: Text('Buy Now'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BuyNowScreen(product: product)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final String name;
  final double price;
  final String imageUrl;
  final VoidCallback onTap;

  const ProductCard({
    Key? key,
    required this.name,
    required this.price,
    required this.imageUrl,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Image.network(
                imageUrl,
                fit: BoxFit.cover,
                width: double.infinity,
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(fontWeight: FontWeight.bold),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 4),
                  Text(
                    '\$${price.toStringAsFixed(2)}',
                    style: TextStyle(color: Colors.green),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class BuyNowScreen extends StatefulWidget {
  final DocumentSnapshot product;

  const BuyNowScreen({Key? key, required this.product}) : super(key: key);

  @override
  _BuyNowScreenState createState() => _BuyNowScreenState();
}

class _BuyNowScreenState extends State<BuyNowScreen> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  String _address = '';
  String _city = '';
  String _zipCode = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Complete Purchase')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(16.0),
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Full Name'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              },
              onSaved: (value) => _name = value!,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Address'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your address';
                }
                return null;
              },
              onSaved: (value) => _address = value!,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'City'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your city';
                }
                return null;
              },
              onSaved: (value) => _city = value!,
            ),
            TextFormField(
              decoration: InputDecoration(labelText: 'Zip Code'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your zip code';
                }
                return null;
              },
              onSaved: (value) => _zipCode = value!,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Place Order'),
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => OrderSummaryScreen(
                        product: widget.product,
                        name: _name,
                        address: _address,
                        city: _city,
                        zipCode: _zipCode,
                      ),
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

class OrderSummaryScreen extends StatelessWidget {
  final DocumentSnapshot product;
  final String name;
  final String address;
  final String city;
  final String zipCode;

  const OrderSummaryScreen({
    Key? key,
    required this.product,
    required this.name,
    required this.address,
    required this.city,
    required this.zipCode,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Order Summary')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Product: ${product['name']}'),
            Text('Price: \$${product['price'].toStringAsFixed(2)}'),
            SizedBox(height: 20),
            Text('Shipping Information:'),
            Text(name),
            Text(address),
            Text('$city, $zipCode'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Confirm Order'),
              onPressed: () => _placeOrder(context),
            ),
          ],
        ),
      ),
    );
  }

  void _placeOrder(BuildContext context) async {
    try {
      DocumentReference orderRef = await FirebaseFirestore.instance.collection('orders').add({
        'productId': product.id,
        'name': name,
        'address': address,
        'city': city,
        'zipCode': zipCode,
        'status': 'placed',
        'timestamp': FieldValue.serverTimestamp(),
      });

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => OrderConfirmationScreen(orderId: orderRef.id),
        ),
      );
    } catch (e) {
      print('Error placing order: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to place order. Please try again.')),
      );
    }
  }
}

class OrderConfirmationScreen extends StatelessWidget {
  final String orderId;

  const OrderConfirmationScreen({Key? key, required this.orderId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Order Confirmation')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 64),
            SizedBox(height: 20),
            Text('Order Placed Successfully!'),
            SizedBox(height: 10),
            Text('Order ID: $orderId'),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text('Back to Home'),
              onPressed: () {
                Navigator.of(context).popUntil((route) => route.isFirst);
              },
            ),
          ],
        ),
      ),
    );
  }
}