import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    theme: ThemeData(
      primarySwatch: Colors.green,
      visualDensity: VisualDensity.adaptivePlatformDensity,
    ),
    home: const SmeCalculator(),
  ));
}

class SmeCalculator extends StatefulWidget {
  const SmeCalculator({super.key});

  @override
  _SmeCalculatorState createState() => _SmeCalculatorState();
}

class _SmeCalculatorState extends State<SmeCalculator> {
  final _formKey = GlobalKey<FormState>();
  String _calculationType = 'Gross Margin';
  Map<String, dynamic> _results = {};
  final Map<String, TextEditingController> _controllers = {
    'revenue': TextEditingController(),
    'costOfGoodsSold': TextEditingController(),
    'totalExpenses': TextEditingController(),
    'currentAssets': TextEditingController(),
    'currentLiabilities': TextEditingController(),
    'operatingExpenses': TextEditingController(),
    'taxableIncome': TextEditingController(),
    'debt': TextEditingController(),
    'equity': TextEditingController(),
    'fixedCosts': TextEditingController(),
    'variableCostsPerUnit': TextEditingController(),
    'sellingPricePerUnit': TextEditingController(),
    'cashInflows': TextEditingController(),
    'cashOutflows': TextEditingController(),
    'saleValue': TextEditingController(),
    'gstRate': TextEditingController(),
  };

  final Map<String, String> _definitions = {
    'Gross Margin':
        'The difference between revenue and cost of goods sold, divided by revenue. It helps measure a company\'s financial health and efficiency in managing production costs.',
    'Net Profit Margin':
        'The percentage of revenue left after all expenses, taxes, and costs have been deducted from total sales.',
    'Operating Income':
        'Profit earned from a firm\'s core business operations, excluding deductions of interest and taxes.',
    'Working Capital':
        'A measure of a company\'s short-term financial health, calculated as current assets minus current liabilities.',
    'GST Calculation':
        'Calculation of Goods and Services Tax based on the sale value and applicable GST rate.',
    'Income Tax (SME-specific)':
        'Calculation of income tax specifically for SMEs, considering potential rebates or special schemes.',
    'Interest on Loans':
        'Calculation of interest payable on loans, which is crucial for rural SMEs relying on government-backed loans.',
    'Cash Flow':
        'The net amount of cash and cash-equivalents moving into and out of a business.',
    'Debt-to-Equity Ratio':
        'A measure of the proportion of debt and equity used to finance a company\'s assets, helping rural businesses understand their financial leverage.',
    'Break-even Point':
        'The point at which total cost and total revenue are equal, i.e., no net loss or gain, which is important for small businesses to understand when they will start becoming profitable.',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rural SME Financial Calculator',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green[700],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _buildCalculationTypeDropdown(),
              const SizedBox(height: 20),
              _buildCalculationForm(),
              const SizedBox(height: 20),
              _buildResultsSection(),
              const SizedBox(height: 20),
              _buildDefinitionSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCalculationTypeDropdown() {
    return DropdownButtonFormField<String>(
      value: _calculationType,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        filled: true,
        fillColor: Colors.green[50],
      ),
      onChanged: (String? newValue) {
        setState(() {
          _calculationType = newValue!;
          _results.clear();
        });
      },
      items: _definitions.keys.map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }

  Widget _buildCalculationForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: <Widget>[
          if (_calculationType == 'Gross Margin') ...[
            _buildTextFormField(_controllers['revenue']!, 'Revenue'),
            _buildTextFormField(
                _controllers['costOfGoodsSold']!, 'Cost of Goods Sold'),
          ] else if (_calculationType == 'Net Profit Margin') ...[
            _buildTextFormField(_controllers['revenue']!, 'Revenue'),
            _buildTextFormField(
                _controllers['totalExpenses']!, 'Total Expenses'),
          ] else if (_calculationType == 'Operating Income') ...[
            _buildTextFormField(_controllers['revenue']!, 'Revenue'),
            _buildTextFormField(
                _controllers['operatingExpenses']!, 'Operating Expenses'),
          ] else if (_calculationType == 'Working Capital') ...[
            _buildTextFormField(
                _controllers['currentAssets']!, 'Current Assets'),
            _buildTextFormField(
                _controllers['currentLiabilities']!, 'Current Liabilities'),
          ] else if (_calculationType == 'GST Calculation') ...[
            _buildTextFormField(_controllers['saleValue']!, 'Sale Value'),
            _buildTextFormField(_controllers['gstRate']!, 'GST Rate (%)'),
          ] else if (_calculationType == 'Income Tax (SME-specific)') ...[
            _buildTextFormField(
                _controllers['taxableIncome']!, 'Taxable Income'),
          ] else if (_calculationType == 'Interest on Loans') ...[
            _buildTextFormField(_controllers['debt']!, 'Loan Amount'),
            _buildTextFormField(_controllers['gstRate']!,
                'Interest Rate (%)'), // Reusing gstRate controller for interest rate
          ] else if (_calculationType == 'Cash Flow') ...[
            _buildTextFormField(_controllers['cashInflows']!, 'Cash Inflows'),
            _buildTextFormField(_controllers['cashOutflows']!, 'Cash Outflows'),
          ] else if (_calculationType == 'Debt-to-Equity Ratio') ...[
            _buildTextFormField(_controllers['debt']!, 'Total Debt'),
            _buildTextFormField(_controllers['equity']!, 'Total Equity'),
          ] else if (_calculationType == 'Break-even Point') ...[
            _buildTextFormField(_controllers['fixedCosts']!, 'Fixed Costs'),
            _buildTextFormField(_controllers['variableCostsPerUnit']!,
                'Variable Costs per Unit'),
            _buildTextFormField(
                _controllers['sellingPricePerUnit']!, 'Selling Price per Unit'),
          ],
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _submitForm,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green[300],
              padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
            ),
            child: Text('Calculate'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextFormField(TextEditingController controller, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        keyboardType: TextInputType.number,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter a value';
          }
          if (double.tryParse(value) == null) {
            return 'Please enter a valid number';
          }
          return null;
        },
      ),
    );
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        switch (_calculationType) {
          case 'Gross Margin':
            _results = _calculateGrossMargin(
              double.parse(_controllers['revenue']!.text),
              double.parse(_controllers['costOfGoodsSold']!.text),
            );
            break;
          case 'Net Profit Margin':
            _results = _calculateNetProfitMargin(
              double.parse(_controllers['revenue']!.text),
              double.parse(_controllers['totalExpenses']!.text),
            );
            break;
          case 'Operating Income':
            _results = _calculateOperatingIncome(
              double.parse(_controllers['revenue']!.text),
              double.parse(_controllers['operatingExpenses']!.text),
            );
            break;
          case 'Working Capital':
            _results = _calculateWorkingCapital(
              double.parse(_controllers['currentAssets']!.text),
              double.parse(_controllers['currentLiabilities']!.text),
            );
            break;
          case 'GST Calculation':
            _results = _calculateGST(
              double.parse(_controllers['saleValue']!.text),
              double.parse(_controllers['gstRate']!.text),
            );
            break;
          case 'Income Tax (SME-specific)':
            _results = _calculateSMEIncomeTax(
              double.parse(_controllers['taxableIncome']!.text),
            );
            break;
          case 'Interest on Loans':
            _results = _calculateInterestOnLoans(
              double.parse(_controllers['debt']!.text),
              double.parse(_controllers['gstRate']!.text),
            );
            break;
          case 'Cash Flow':
            _results = _calculateCashFlow(
              double.parse(_controllers['cashInflows']!.text),
              double.parse(_controllers['cashOutflows']!.text),
            );
            break;
          case 'Debt-to-Equity Ratio':
            _results = _calculateDebtToEquityRatio(
              double.parse(_controllers['debt']!.text),
              double.parse(_controllers['equity']!.text),
            );
            break;
          case 'Break-even Point':
            _results = _calculateBreakEvenPoint(
              double.parse(_controllers['fixedCosts']!.text),
              double.parse(_controllers['variableCostsPerUnit']!.text),
              double.parse(_controllers['sellingPricePerUnit']!.text),
            );
            break;
        }
      });
    }
  }

  Widget _buildResultsSection() {
    if (_results.isEmpty) return const SizedBox.shrink();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Results',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ..._results.entries.map((entry) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(entry.key,
                          style: const TextStyle(fontWeight: FontWeight.w500)),
                      Text(entry.value,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildDefinitionSection() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Definition',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(_definitions[_calculationType] ?? '',
                style: const TextStyle(fontStyle: FontStyle.italic)),
          ],
        ),
      ),
    );
  }

  Map<String, String> _calculateGrossMargin(
      double revenue, double costOfGoodsSold) {
    if (revenue == 0) {
      return {'Gross Margin': 'Undefined (Revenue is zero)'};
    }
    double grossMargin = ((revenue - costOfGoodsSold) / revenue) * 100;
    return {'Gross Margin': '${grossMargin.toStringAsFixed(2)}%'};
  }

  Map<String, String> _calculateNetProfitMargin(
      double revenue, double totalExpenses) {
    if (revenue == 0) {
      return {'Net Profit Margin': 'Undefined (Revenue is zero)'};
    }
    double netProfit = revenue - totalExpenses;
    double netProfitMargin = (netProfit / revenue) * 100;
    return {'Net Profit Margin': '${netProfitMargin.toStringAsFixed(2)}%'};
  }

  Map<String, String> _calculateOperatingIncome(
      double revenue, double operatingExpenses) {
    double operatingIncome = revenue - operatingExpenses;
    return {'Operating Income': '\$${operatingIncome.toStringAsFixed(2)}'};
  }

  Map<String, String> _calculateWorkingCapital(
      double currentAssets, double currentLiabilities) {
    double workingCapital = currentAssets - currentLiabilities;
    return {'Working Capital': '\$${workingCapital.toStringAsFixed(2)}'};
  }

  Map<String, String> _calculateGST(double saleValue, double gstRate) {
    double gstAmount = saleValue * (gstRate / 100);
    return {
      'GST Amount': '\$${gstAmount.toStringAsFixed(2)}',
      'Total Price (including GST)':
          '\$${(saleValue + gstAmount).toStringAsFixed(2)}'
    };
  }

  Map<String, String> _calculateSMEIncomeTax(double taxableIncome) {
    // This is a simplified calculation. In reality, SME income tax can be complex and vary by region.
    double taxRate = 0.15; // Assuming a 15% tax rate for SMEs
    double taxAmount = taxableIncome * taxRate;
    return {'Estimated SME Income Tax': '\$${taxAmount.toStringAsFixed(2)}'};
  }

  Map<String, String> _calculateInterestOnLoans(
      double loanAmount, double interestRate) {
    double annualInterest = loanAmount * (interestRate / 100);
    return {'Annual Interest': '\$${annualInterest.toStringAsFixed(2)}'};
  }

  Map<String, String> _calculateCashFlow(
      double cashInflows, double cashOutflows) {
    double netCashFlow = cashInflows - cashOutflows;
    return {'Net Cash Flow': '\$${netCashFlow.toStringAsFixed(2)}'};
  }

  Map<String, String> _calculateDebtToEquityRatio(double debt, double equity) {
    if (equity == 0) {
      return {'Debt-to-Equity Ratio': 'Undefined (Equity is zero)'};
    }
    double debtToEquityRatio = debt / equity;
    return {'Debt-to-Equity Ratio': debtToEquityRatio.toStringAsFixed(2)};
  }

  Map<String, String> _calculateBreakEvenPoint(double fixedCosts,
      double variableCostsPerUnit, double sellingPricePerUnit) {
    if (sellingPricePerUnit - variableCostsPerUnit == 0) {
      return {'Break-even Point': 'Undefined (Price equals Variable Cost)'};
    }
    double breakEvenUnits =
        fixedCosts / (sellingPricePerUnit - variableCostsPerUnit);
    double breakEvenRevenue = breakEvenUnits * sellingPricePerUnit;
    return {
      'Break-even Units': breakEvenUnits.toStringAsFixed(2),
      'Break-even Revenue': '\$${breakEvenRevenue.toStringAsFixed(2)}'
    };
  }
}

class FinancialDataInputPage extends StatelessWidget {
  const FinancialDataInputPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Financial Data Input'),
      ),
      body: const Center(
        child: Text('Future financial data input page'),
      ),
    );
  }
}
