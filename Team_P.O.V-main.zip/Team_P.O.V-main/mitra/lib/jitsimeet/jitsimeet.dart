import 'package:flutter/material.dart';
import 'package:jitsi_meet_flutter_sdk/jitsi_meet_flutter_sdk.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Firebase Firestore
import 'package:firebase_auth/firebase_auth.dart'; // Firebase Authentication

class JitsiMeetScreen extends StatefulWidget {
  const JitsiMeetScreen({super.key, required this.title});
  final String title;

  @override
  State<JitsiMeetScreen> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<JitsiMeetScreen> {
  final meetingNameController = TextEditingController();
  final jitsiMeet = JitsiMeet();
  bool isLoading = true;
  String displayName = "Flutter User";

  @override
  void initState() {
    super.initState();
    fetchUserName();
  }

  Future<void> fetchUserName() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        // Fetch the user's type (investor or sme)
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (userDoc.exists) {
          String userType = userDoc['userType']; // Assuming 'type' field exists
          String collectionName = userType == 'Investor' ? 'investors' : 'sme';

          // Fetch name from the corresponding collection
          DocumentSnapshot nameDoc = await FirebaseFirestore.instance
              .collection(collectionName)
              .doc(user.uid)
              .get();

          if (nameDoc.exists) {
            setState(() {
              displayName = nameDoc['name']; // Assuming 'name' field exists
              isLoading = false;
            });
          }
        }
      }
    } catch (error) {
      print("Error fetching user name: $error");
    }
  }

  void join() {
    String roomName = meetingNameController.text.isNotEmpty
        ? meetingNameController.text
        : "testRoom";

    var options = JitsiMeetConferenceOptions(
      serverURL: "https://meet.ffmuc.net/",
      room: roomName,
      configOverrides: {
        "startWithAudioMuted": false,
        "startWithVideoMuted": false,
      },
      userInfo: JitsiMeetUserInfo(
        displayName: displayName, // Use the fetched name
        email: "", // Email is optional
      ),
    );

    jitsiMeet.join(options).catchError((error) {
      print("Error joining meeting: $error");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator()) // Show a loader while fetching data
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  TextField(
                    controller: meetingNameController,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Enter meeting name',
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: join,
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      child: const Text("Join Meeting", style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
