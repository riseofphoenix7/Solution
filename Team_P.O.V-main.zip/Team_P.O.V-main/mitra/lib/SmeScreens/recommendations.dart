class SME {
  final String companyName;
  final String sector;
  final int employeeCount;
  final double revenue;
  final double profit;
  final double cashFlow;
  final double fundingNeeds;
  final double valuation;

  SME({
    required this.companyName,
    required this.sector,
    required this.employeeCount,
    required this.revenue,
    required this.profit,
    required this.cashFlow,
    required this.fundingNeeds,
    required this.valuation,
  });
}

class Investor {
  final Map<String, String> preferences;

  Investor({required this.preferences});
}

class InvestorRecommendationSystem {
  int _calculateScore(SME sme, Investor investor) {
    int score = 0;

    // Match sector
    if (investor.preferences['question_1'] == 'Tech Startups' &&
        sme.sector == 'Information Technology') {
      score += 20;
    }

    // Match investment size
    if (investor.preferences['question_3'] == '< \$50K' &&
        sme.fundingNeeds <= 50000) {
      score += 15;
    }

    // Match sector experience
    if (investor.preferences['question_5'] == sme.sector) {
      score += 15;
    }

    // Match rural preference
    if (investor.preferences['question_6'] == 'Yes') {
      score += 10;
    }

    // Match risk tolerance (assuming higher valuation means lower risk)
    if (investor.preferences['question_9'] == 'Low' &&
        sme.valuation > 1000000) {
      score += 10;
    }

    // Match ROI expectations (simple calculation, can be made more sophisticated)
    double estimatedROI = (sme.profit / sme.valuation) * 100;
    if (investor.preferences['question_12'] == '5-10%' &&
        estimatedROI >= 5 &&
        estimatedROI <= 10) {
      score += 15;
    }

    return score;
  }

  List<Map<String, dynamic>> getRecommendations(
      List<SME> smes, Investor investor) {
    List<Map<String, dynamic>> recommendations = [];

    for (var sme in smes) {
      int score = _calculateScore(sme, investor);
      recommendations.add({
        'sme': sme,
        'score': score,
      });
    }

    recommendations.sort((a, b) => b['score'].compareTo(a['score']));
    return recommendations;
  }
}

// Usage example