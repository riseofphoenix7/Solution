import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Smechatbot extends StatefulWidget {
  const Smechatbot({super.key});

  @override
  _SmechatbotState createState() => _SmechatbotState();
}

class _SmechatbotState extends State<Smechatbot> {
  late WebViewController _controller;
  String _currentUrl = '';
  String _currentTitle = '';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            print("Loading...");
          },
          onPageFinished: (String url) {
            print("Loading...");
          },
        ),
      );
  }

  void _loadChatbot(String title, String url) {
    setState(() {
      _currentUrl = url;
      _currentTitle = title;
    });
    _controller.loadRequest(Uri.parse(url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blue.shade900,
                  Colors.blue.shade500,
                ],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const Text(
                    'Welcome to Our Chatbot Hub',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Choose your virtual assistant',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildChatbotButton(
                        'Loan Mitra',
                        Icons.attach_money,
                        'https://cozy-griffin-4323e7.netlify.app/',
                      ),
                      _buildChatbotButton(
                        'Research Mitra',
                        Icons.science,
                        'https://bright-pasca-dc465a.netlify.app/',
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
          Expanded(
            child: _currentUrl.isNotEmpty
                ? WebViewWidget(controller: _controller)
                : const Center(
                    child: Text('Select a chatbot to begin'),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatbotButton(String title, IconData icon, String url) {
    bool isSelected = _currentTitle == title;
    return ElevatedButton(
      onPressed: () => _loadChatbot(title, url),
      style: ElevatedButton.styleFrom(
        backgroundColor: isSelected ? Colors.white : Colors.blue.shade700,
        foregroundColor: isSelected ? Colors.blue.shade900 : Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 24),
          const SizedBox(height: 5),
          Text(title, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
