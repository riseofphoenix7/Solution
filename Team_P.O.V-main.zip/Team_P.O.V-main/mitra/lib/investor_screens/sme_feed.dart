import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SME Feed',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: SMEFeed(),
    );
  }
}

class SMEFeed extends StatelessWidget {
  const SMEFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SME Feed',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green[700],
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('smes').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No SMEs found'));
          }
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var sme =
                  snapshot.data!.docs[index].data() as Map<String, dynamic>;
              return SMECard(sme: sme);
            },
          );
        },
      ),
    );
  }
}

class SMECard extends StatelessWidget {
  final Map<String, dynamic> sme;

  const SMECard({super.key, required this.sme});

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DetailedSMEView(sme: sme)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        sme['logoUrl'] ?? 'https://via.placeholder.com/60'),
                    radius: 30,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sme['companyName'] ?? 'Company Name',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        Text(sme['sector'] ?? 'Sector',
                            style: TextStyle(color: Colors.grey[600])),
                        const SizedBox(height: 4),
                        Text(sme['phone'] ?? 'N/A',
                            style: TextStyle(color: Colors.green[700])),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                sme['companyDescription'] ?? 'No description available',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                      'Revenue: ₹${formatter.format((sme['revenue'] ?? 0) / 100000)} L',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Employees: ${sme['employeeCount'] ?? 'N/A'}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildIconButton(
                      Icons.email, 'Email', () => _launchEmail(sme['email'])),
                  _buildIconButton(Icons.video_call, 'Video Chat',
                      () => _launchVideoCall(sme['videoCallLink'])),
                  _buildIconButton(Icons.message, 'Message',
                      () => _launchMessage(sme['phone'])),
                  _buildIconButton(Icons.psychology, 'Ask Mitra AI',
                      () => _showAIInsights(context, sme)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: Colors.green[700]),
          onPressed: onPressed,
        ),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  void _launchEmail(String? email) async {
    if (email != null) {
      final Uri emailLaunchUri = Uri(scheme: 'mailto', path: email);
      if (await canLaunch(emailLaunchUri.toString())) {
        await launch(emailLaunchUri.toString());
      }
    }
  }

  void _launchVideoCall(String? link) async {
    if (link != null && await canLaunch(link)) {
      await launch(link);
    }
  }

  void _launchMessage(String? phone) async {
    if (phone != null) {
      final Uri smsLaunchUri = Uri(scheme: 'sms', path: phone);
      if (await canLaunch(smsLaunchUri.toString())) {
        await launch(smsLaunchUri.toString());
      }
    }
  }

  void _showAIInsights(BuildContext context, Map<String, dynamic> sme) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          title: Text('Generating AI Insights'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Please wait while we analyze the SME data...'),
            ],
          ),
        );
      },
    );

    try {
      final insights = await getAIInsights(sme);
      Navigator.of(context).pop(); // Close the loading dialog
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => AIInsightsView(insights: insights)),
      );
    } catch (e) {
      Navigator.of(context).pop(); // Close the loading dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text(
                'Failed to generate AI insights. Please try again later.'),
            actions: [
              TextButton(
                child: const Text('OK'),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          );
        },
      );
    }
  }

  Future<Map<String, dynamic>> getAIInsights(Map<String, dynamic> sme) async {
    const apiKey =
        'YOUR_GEMINI_API_KEY'; // Replace with your actual Gemini API key
    final url =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey';

    final prompt = '''
    Analyze the following SME (Small and Medium Enterprise) data and provide insights for potential investors:

    Company Name: ${sme['companyName']}
    Sector: ${sme['sector']}
    Revenue: ${sme['revenue']}
    Profit: ${sme['profit']}
    Business Valuation: ${sme['businessValuation']}
    Funding Needs: ${sme['fundingNeeds']}
    Employee Count: ${sme['employeeCount']}
    Customers Served: ${sme['customersServed']}
    B2B Businesses Served: ${sme['b2bBusinessesServed']}
    Company Description: ${sme['companyDescription']}
    Unique Selling Proposition: ${sme['uniqueSellingProposition']}
    Business Models: ${sme['businessModels']}

    Please provide the following:
    1. A brief summary of the company (2-3 sentences)
    2. An analysis of the company's financial health (2-3 bullet points)
    3. Market potential and growth opportunities (2-3 bullet points)
    4. Potential risks or challenges (2-3 bullet points)
    5. Overall investment recommendation (1 sentence)

    Format the response as a JSON object with keys: summary, financialHealth, marketPotential, risks, recommendation.
    ''';

    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ]
      }),
    );

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      final generatedContent =
          jsonResponse['candidates'][0]['content']['parts'][0]['text'];
      return jsonDecode(generatedContent);
    } else {
      throw Exception(
          'Failed to generate AI insights: ${response.statusCode} ${response.reasonPhrase}');
    }
  }
}

class DetailedSMEView extends StatelessWidget {
  final Map<String, dynamic> sme;

  const DetailedSMEView({super.key, required this.sme});

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Scaffold(
      appBar: AppBar(
        title: Text(sme['companyName'] ?? 'Company Details'),
        backgroundColor: Colors.green[700],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    sme['logoUrl'] ?? 'https://via.placeholder.com/120'),
                radius: 60,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              sme['companyName'] ?? 'Company Name',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              sme['sector'] ?? 'Sector',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            _buildInfoCard('Company Overview', [
              _buildInfoRow('Address', sme['address'] ?? 'N/A'),
              _buildInfoRow('Website', sme['website'] ?? 'N/A'),
              _buildInfoRow('Phone', sme['phone'] ?? 'N/A'),
              _buildInfoRow('Email', sme['email'] ?? 'N/A'),
            ]),
            const SizedBox(height: 16),
            _buildInfoCard('Financial Information', [
              _buildInfoRow('Revenue',
                  '₹${formatter.format((sme['revenue'] ?? 0) / 100000)} Lakhs'),
              _buildInfoRow('Profit',
                  '₹${formatter.format((sme['profit'] ?? 0) / 100000)} Lakhs'),
              _buildInfoRow('Valuation',
                  '₹${formatter.format((sme['businessValuation'] ?? 0) / 100000)} Lakhs'),
              _buildInfoRow('Funding Needs',
                  '₹${formatter.format((sme['fundingNeeds'] ?? 0) / 100000)} Lakhs'),
            ]),
            const SizedBox(height: 16),
            _buildInfoCard('Company Metrics', [
              _buildInfoRow(
                  'Employees', sme['employeeCount']?.toString() ?? 'N/A'),
              _buildInfoRow('Customers Served',
                  sme['customersServed']?.toString() ?? 'N/A'),
              _buildInfoRow('B2B Businesses Served',
                  sme['b2bBusinessesServed']?.toString() ?? 'N/A'),
            ]),
            const SizedBox(height: 24),
            const Text('Company Description',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(sme['companyDescription'] ?? 'No description available.'),
            const SizedBox(height: 24),
            const Text('Unique Selling Proposition',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(sme['uniqueSellingProposition'] ?? 'No USP available.'),
            const SizedBox(height: 24),
            const Text('Business Model',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: (sme['businessModels'] as List<dynamic>? ?? [])
                  .map((model) => Chip(
                        label: Text(model),
                        backgroundColor: Colors.green[100],
                        labelStyle: TextStyle(color: Colors.green[700]),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => _showAIInsights(context, sme),
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
              child: Text('Get AI Insights'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[700])),
            const SizedBox(height: 8),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(value, style: TextStyle(color: Colors.grey[800])),
        ],
      ),
    );
  }

  void _showAIInsights(BuildContext context, Map<String, dynamic> sme) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return const AlertDialog(
          title: Text('Generating AI Insights'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Please wait while we analyze the SME data...'),
            ],
          ),
        );
      },
    );

    try {
      final insights = await getAIInsights(sme);
      Navigator.of(context).pop(); // Close the loading dialog
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => AIInsightsView(insights: insights)),
      );
    } catch (e) {
      Navigator.of(context).pop(); // Close the loading dialog
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error'),
            content: const Text(
                'Failed to generate AI insights. Please try again later.'),
            actions: [
              TextButton(
                child: const Text('OK'),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ],
          );
        },
      );
    }
  }

  Future<Map<String, dynamic>> getAIInsights(Map<String, dynamic> sme) async {
    const apiKey =
        'YOUR_GEMINI_API_KEY'; // Replace with your actual Gemini API key
    final url =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$apiKey';

    final prompt = '''
    Analyze the following SME (Small and Medium Enterprise) data and provide insights for potential investors:

    Company Name: ${sme['companyName']}
    Sector: ${sme['sector']}
    Revenue: ${sme['revenue']}
    Profit: ${sme['profit']}
    Business Valuation: ${sme['businessValuation']}
    Funding Needs: ${sme['fundingNeeds']}
    Employee Count: ${sme['employeeCount']}
    Customers Served: ${sme['customersServed']}
    B2B Businesses Served: ${sme['b2bBusinessesServed']}
    Company Description: ${sme['companyDescription']}
    Unique Selling Proposition: ${sme['uniqueSellingProposition']}
    Business Models: ${sme['businessModels']}

    Please provide the following:
    1. A brief summary of the company (2-3 sentences)
    2. An analysis of the company's financial health (2-3 bullet points)
    3. Market potential and growth opportunities (2-3 bullet points)
    4. Potential risks or challenges (2-3 bullet points)
    5. Overall investment recommendation (1 sentence)

    Format the response as a JSON object with keys: summary, financialHealth, marketPotential, risks, recommendation.
    ''';

    final response = await http.post(
      Uri.parse(url),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt}
            ]
          }
        ]
      }),
    );

    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      final generatedContent =
          jsonResponse['candidates'][0]['content']['parts'][0]['text'];
      return jsonDecode(generatedContent);
    } else {
      throw Exception(
          'Failed to generate AI insights: ${response.statusCode} ${response.reasonPhrase}');
    }
  }
}

class AIInsightsView extends StatelessWidget {
  final Map<String, dynamic> insights;

  const AIInsightsView({super.key, required this.insights});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Insights'),
        backgroundColor: Colors.green[700],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection('Summary', insights['summary']),
            _buildSection('Financial Health', insights['financialHealth']),
            _buildSection('Market Potential', insights['marketPotential']),
            _buildSection('Risks', insights['risks']),
            _buildSection('Recommendation', insights['recommendation']),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, dynamic content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (content is String)
          Text(content)
        else if (content is List)
          Column(
            children: content
                .map((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('• ',
                              style: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.bold)),
                          Expanded(child: Text(item)),
                        ],
                      ),
                    ))
                .toList(),
          ),
        const SizedBox(height: 16),
      ],
    );
  }
}
