import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'forumpost.dart'; // Import the PostCard widget
import 'createpost.dart'; // Import the CreatePost widget

class Forums extends StatelessWidget {
  final String topicId; // Add this to receive the topic ID

  const Forums({super.key, required this.topicId});

  Future<String?> _getInvestorId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      return user.uid; // Use this as the investorId if it matches
    }
    return null;
  }

  Future<void> _followTopic() async {
    String? investorId = await _getInvestorId();
    if (investorId == null) {
      // Handle case where investorId is not found
      return;
    }

    // Update the user's followed topics
    await FirebaseFirestore.instance
        .collection('users')
        .doc(investorId)
        .update({
      'followedTopics':
          FieldValue.arrayUnion([topicId]), // Add topicId to followedTopics
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forums: $topicId'), // Display the topicId in the AppBar
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Column(
        children: [
          ElevatedButton(
            onPressed: () async {
              // Fetch followed topics to pass to CreatePost
              final investorId = await _getInvestorId();
              if (investorId == null) return;

              // Show CreatePost dialog
              final userDoc = await FirebaseFirestore.instance
                  .collection('users')
                  .doc(investorId)
                  .get();
              List<dynamic> followedTopics = userDoc['followedTopics'] ?? [];

              showDialog(
                context: context,
                builder: (context) => CreatePost(
                    topics: List<String>.from(
                        followedTopics)), // Pass followed topics
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            child: const Text('Add New Post'), // Customize the button color
          ),
          ElevatedButton(
            onPressed: _followTopic,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
            child:
                const Text('Follow this Topic'), // Customize the button color
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              // Filter posts by the topicId
              stream: FirebaseFirestore.instance
                  .collection('posts')
                  .where('topicId', isEqualTo: topicId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }
                final posts = snapshot.data?.docs ?? [];

                return ListView.builder(
                  itemCount: posts.length,
                  itemBuilder: (context, index) {
                    final post = posts[index].data() as Map<String, dynamic>;
                    final userId = post[
                        'investorId']; // Assuming you have investorId in the post

                    return PostCard(
                      title: post['title'],
                      content: post['content'],
                      investorId: userId,
                      timestamp:
                          post['timestamp'], // Pass the timestamp directly
                      postId: posts[index].id, // Pass the post ID here
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
