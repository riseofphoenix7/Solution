import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:intl/intl.dart';
import 'package:mitra/jitsimeet/meetscheduler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'DetailedInvestorView.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Investor Feed',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: InvestorFeed(),
    );
  }
}

class InvestorFeed extends StatelessWidget {
  const InvestorFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Investor Feed',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.indigo[700],
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('investors').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No Investors found'));
          }
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var investorDoc = snapshot.data!.docs[index];
              var investor = investorDoc.data() as Map<String, dynamic>;
              String uid = investorDoc.id;

              return InvestorCard(investor: investor, uid: uid);
            },
          );
        },
      ),
    );
  }
}

class InvestorCard extends StatelessWidget {
  final Map<String, dynamic> investor;
  final String uid;

  const InvestorCard({super.key, required this.investor, required this.uid});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailedInvestorView(investorId: uid),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(investor['profileImageUrl'] ??
                        'https://via.placeholder.com/60'),
                    radius: 30,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          investor['name'] ?? 'Investor Name',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        Wrap(
                          spacing: 4,
                          children: (investor['preferredInvestors']
                                      as List<dynamic>? ??
                                  [])
                              .take(2)
                              .map((sector) => Chip(
                                    label: Text(sector,
                                        style: const TextStyle(fontSize: 12)),
                                    backgroundColor: Colors.indigo[50],
                                  ))
                              .toList(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                investor['bio'] ?? 'No description available',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'investmentRange',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildIconButton(Icons.email, 'Email',
                      () => _launchEmail(investor['email'])),
                  _buildIconButton(Icons.web, 'Website',
                      () => _launchWebsite(investor['website'])),
                  _buildIconButton(Icons.business, 'Portfolio',
                      () => _showPortfolio(context, investor)),
                  _buildIconButton(Icons.video_call, 'Initiate Meet', () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MeetScheduler(targetUser: uid),
                      ),
                    );
                  }),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: Colors.indigo[700]),
          onPressed: onPressed,
        ),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  void _launchEmail(String? email) async {
    if (email != null) {
      final Uri emailLaunchUri = Uri(scheme: 'mailto', path: email);
      if (await canLaunch(emailLaunchUri.toString())) {
        await launch(emailLaunchUri.toString());
      }
    }
  }

  void _launchWebsite(String? website) async {
    if (website != null && await canLaunch(website)) {
      await launch(website);
    }
  }

  void _showPortfolio(BuildContext context, Map<String, dynamic> investor) {
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => PortfolioView(investorId: investor['id']),
    //   ),
    // );
  }
}
