import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class SMEDashboard extends StatefulWidget {
  @override
  _SMEDashboardState createState() => _SMEDashboardState();
}

class _SMEDashboardState extends State<SMEDashboard> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Map<String, dynamic> smeData = {};
  bool isLoading = true;
  String selectedSector = 'Technology';
  List<String> sectors = [
    'Technology',
    'Finance',
    'Healthcare',
    'Retail',
    'Manufacturing'
  ];
  List<Map<String, dynamic>> managementTeam = [];

  String selectedGoal = 'Increase Revenue';
  String selectedAchievement = 'Expand Marketing Efforts';
  List<String> goals = [
    'Increase Revenue',
    'Expand Market Share',
    'Launch New Product',
    'Improve Customer Satisfaction',
    'Reduce Costs',
    'Enter New Market',
    'Raise Funding'
  ];
  List<String> achievements = [
    'Expand Marketing Efforts',
    'Hire Key Personnel',
    'Develop New Technology',
    'Form Strategic Partnerships',
    'Streamline Operations',
    'Conduct Market Research',
    'Secure Investment'
  ];

  List<String> businessModels = ['B2B', 'B2C', 'C2C', 'D2C', 'B2G'];

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _loadSMEData();
    _loadManagementTeam();
  }

  Future<void> _loadSMEData() async {
    setState(() => isLoading = true);

    User? user = _auth.currentUser;
    if (user != null) {
      DocumentSnapshot doc =
          await _firestore.collection('smes').doc(user.uid).get();
      if (doc.exists) {
        setState(() {
          smeData = doc.data() as Map<String, dynamic>;
          selectedSector = sectors.contains(smeData['sector'])
              ? smeData['sector']
              : (sectors.isNotEmpty ? sectors[0] : '');
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _loadManagementTeam() async {
    User? user = _auth.currentUser;
    if (user != null) {
      QuerySnapshot teamSnapshot = await _firestore
          .collection('smes')
          .doc(user.uid)
          .collection('management_team')
          .get();
      setState(() {
        managementTeam = teamSnapshot.docs
            .map((doc) => doc.data() as Map<String, dynamic>)
            .toList();
      });
    }
  }

  Future<void> _saveData() async {
    if (_formKey.currentState!.validate()) {
      User? user = _auth.currentUser;
      if (user != null) {
        await _firestore
            .collection('smes')
            .doc(user.uid)
            .set(smeData, SetOptions(merge: true));
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Data saved successfully'),
          backgroundColor: Colors.green,
        ));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Please fill all required fields'),
        backgroundColor: Colors.red,
      ));
    }
  }

  void _addTeamMember() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String name = '';
        String position = '';
        String linkedinUrl = '';

        return AlertDialog(
          title: Text('Add Team Member'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                decoration: InputDecoration(labelText: 'Name'),
                onChanged: (value) => name = value,
                validator: (value) =>
                    value?.isEmpty ?? true ? 'Name is required' : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'Position'),
                onChanged: (value) => position = value,
                validator: (value) =>
                    value?.isEmpty ?? true ? 'Position is required' : null,
              ),
              TextFormField(
                decoration: InputDecoration(labelText: 'LinkedIn URL'),
                onChanged: (value) => linkedinUrl = value,
              ),
            ],
          ),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: Text('Add'),
              onPressed: () async {
                if (name.isNotEmpty && position.isNotEmpty) {
                  User? user = _auth.currentUser;
                  if (user != null) {
                    await _firestore
                        .collection('smes')
                        .doc(user.uid)
                        .collection('management_team')
                        .add({
                      'name': name,
                      'position': position,
                      'linkedinUrl': linkedinUrl,
                    });
                    _loadManagementTeam();
                    Navigator.of(context).pop();
                  }
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Name and Position are required'),
                    backgroundColor: Colors.red,
                  ));
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _uploadProfilePhoto() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      File file = File(image.path);
      User? user = _auth.currentUser;

      if (user != null) {
        try {
          print('Uploading file to Firebase Storage');
          TaskSnapshot snapshot = await _storage
              .ref('profile_photos/${user.uid}.jpg')
              .putFile(file);

          print('Getting download URL');
          String downloadUrl = await snapshot.ref.getDownloadURL();

          print('Updating Firestore document');

          // Check if the document exists before updating
          DocumentSnapshot docSnapshot =
              await _firestore.collection('smes').doc(user.uid).get();

          if (docSnapshot.exists) {
            await _firestore.collection('smes').doc(user.uid).update({
              'logoUrl': downloadUrl,
            });
          } else {
            // If the document doesn't exist, create it
            await _firestore.collection('smes').doc(user.uid).set({
              'logoUrl': downloadUrl,
            }, SetOptions(merge: true));
          }

          print('Updating local state');
          setState(() {
            smeData['logoUrl'] = downloadUrl;
          });

          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Profile photo updated successfully'),
            backgroundColor: Colors.green,
          ));
        } catch (e) {
          print('Error during profile photo update: ${e.toString()}');
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Failed to update profile photo: ${e.toString()}'),
            backgroundColor: Colors.red,
          ));
        }
      } else {
        print('No user logged in');
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('No user logged in'),
          backgroundColor: Colors.red,
        ));
      }
    } else {
      print('No image selected');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            SvgPicture.asset('assets/mitra_logo.svg',
                height: 24, color: Colors.white),
            SizedBox(width: 8),
            Text('MITRA SME Dashboard'),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadSMEData,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              SizedBox(height: 20),
              _buildFinancialOverview(),
              SizedBox(height: 20),
              _buildBasicInformation(),
              SizedBox(height: 20),
              _buildCompanyDescription(),
              SizedBox(height: 20),
              _buildGoalsAndUSP(),
              SizedBox(height: 20),
              _buildSectorDropdown(),
              SizedBox(height: 20),
              _buildBusinessModelSection(),
              SizedBox(height: 20),
              _buildCustomersServedSection(),
              SizedBox(height: 20),
              _buildSaveButton(),
              SizedBox(height: 20),
              _buildManagementTeam(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          children: [
            GestureDetector(
              onTap: _uploadProfilePhoto,
              child: CircleAvatar(
                radius: 40,
                backgroundImage: smeData['logoUrl'] != null
                    ? NetworkImage(smeData['logoUrl']!)
                    : null,
                child: smeData['logoUrl'] == null
                    ? Icon(Icons.camera_alt, color: Colors.white70)
                    : null,
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    initialValue: smeData['companyName'] ?? '',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Enter Company Name',
                    ),
                    validator: (value) => value?.isEmpty ?? true
                        ? 'Company name is required'
                        : null,
                    onChanged: (value) => smeData['companyName'] = value,
                  ),
                  Text(
                    'ID: ${_auth.currentUser?.uid.substring(0, 8) ?? ''}',
                    style: TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Sector: $selectedSector',
                    style: TextStyle(fontSize: 16, color: Colors.teal[700]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialOverview() {
    double maxValue = [
      smeData['revenue'] ?? 0,
      smeData['profit'] ?? 0,
      smeData['cashFlow'] ?? 0,
      smeData['fundingNeeds'] ?? 0,
    ].reduce((a, b) => a > b ? a : b).toDouble();

    // Set a minimum maxY value to prevent issues with very small numbers
    double maxY = maxValue > 1000000 ? maxValue / 100000 : 10;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Financial Overview (in Lakhs)',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            Container(
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  maxY: maxY,
                  barTouchData: BarTouchData(enabled: false),
                  titlesData: FlTitlesData(
                    show: true,
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (double value, TitleMeta meta) {
                          switch (value.toInt()) {
                            case 0:
                              return Text('Revenue');
                            case 1:
                              return Text('Profit');
                            case 2:
                              return Text('Cash Flow');
                            case 3:
                              return Text('Funding');
                            default:
                              return Text('');
                          }
                        },
                        reservedSize: 45,
                      ),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 50,
                        getTitlesWidget: (value, meta) {
                          return Text(
                              '${(value * 100000 / 100000).toStringAsFixed(0)}L');
                        },
                      ),
                    ),
                    topTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                  ),
                  borderData: FlBorderData(show: false),
                  barGroups: [
                    BarChartGroupData(
                      x: 0,
                      barRods: [
                        BarChartRodData(
                            toY: (smeData['revenue'] ?? 0) / 100000,
                            color:
                                Color.lerp(Colors.tealAccent, Colors.teal, 0.5))
                      ],
                      showingTooltipIndicators: [0],
                    ),
                    BarChartGroupData(
                      x: 1,
                      barRods: [
                        BarChartRodData(
                            toY: (smeData['profit'] ?? 0) / 100000,
                            color:
                                Color.lerp(Colors.tealAccent, Colors.teal, 0.5))
                      ],
                      showingTooltipIndicators: [0],
                    ),
                    BarChartGroupData(
                      x: 2,
                      barRods: [
                        BarChartRodData(
                            toY: (smeData['cashFlow'] ?? 0) / 100000,
                            color:
                                Color.lerp(Colors.tealAccent, Colors.teal, 0.5))
                      ],
                      showingTooltipIndicators: [0],
                    ),
                    BarChartGroupData(
                      x: 3,
                      barRods: [
                        BarChartRodData(
                            toY: (smeData['fundingNeeds'] ?? 0) / 100000,
                            color:
                                Color.lerp(Colors.tealAccent, Colors.teal, 0.5))
                      ],
                      showingTooltipIndicators: [0],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            _buildFinancialGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialGrid() {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 12,
      mainAxisSpacing: 1,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        _buildFinancialCard('Revenue in Lakhs', 'revenue', Icons.trending_up),
        _buildFinancialCard('Profit in Lakhs', 'profit', Icons.account_balance),
        _buildFinancialCard('Cash Flow in Lakhs', 'cashFlow', Icons.money),
        _buildFinancialCard(
            'Funding Needs in Lakhs', 'fundingNeeds', Icons.attach_money),
        _buildFinancialCard(
            'Valuation in Lakhs', 'businessValuation', Icons.assessment),
        _buildFinancialCard('Debt in Lakhs', 'debt', Icons.credit_card),
      ],
    );
  }

  Widget _buildFinancialCard(String label, String field, IconData icon) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Card(
      color: Colors.white,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 28, color: Colors.teal),
            SizedBox(height: 4),
            Text(label,
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Colors.blueGrey)),
            SizedBox(height: 4),
            TextFormField(
              initialValue: formatter.format((smeData[field] ?? 0) / 100000),
              keyboardType:
                  TextInputType.numberWithOptions(decimal: true, signed: true),
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal[700]),
              decoration: InputDecoration(
                prefixText: '₹ ',
                border: InputBorder.none,
              ),
              inputFormatters: [
                LengthLimitingTextInputFormatter(
                    11), // 8 digits + 2 decimal places + decimal point
                FilteringTextInputFormatter.allow(
                    RegExp(r'^\d{0,8}(\.\d{0,2})?$')),
              ],
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return '$label is required';
                }
                return null;
              },
              onChanged: (value) {
                value = value.replaceAll(RegExp(r'[^0-9.-]'), '');
                double? parsedValue = double.tryParse(value);
                if (parsedValue != null) {
                  setState(() {
                    smeData[field] =
                        parsedValue * 100000; // Convert back to paise
                  });
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBasicInformation() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Basic Information',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            _buildTextField('Address', 'address', TextInputType.streetAddress),
            _buildTextField('Email', 'email', TextInputType.emailAddress),
            _buildTextField('Phone', 'phone', TextInputType.phone),
            _buildTextField(
                'Number of Employees', 'employeeCount', TextInputType.number),
            _buildTextField('Official Website', 'website', TextInputType.url),
          ],
        ),
      ),
    );
  }

  Widget _buildCompanyDescription() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Company Description',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            TextFormField(
              initialValue: smeData['companyDescription'] ?? '',
              maxLines: 5,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter your company description',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Company description is required';
                }
                return null;
              },
              onChanged: (value) => smeData['companyDescription'] = value,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGoalsAndUSP() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Goals and USP',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedGoal,
              decoration: InputDecoration(labelText: 'Primary Goal'),
              items: goals.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Primary goal is required';
                }
                return null;
              },
              onChanged: (String? newValue) {
                setState(() {
                  selectedGoal = newValue!;
                  smeData['primaryGoal'] = newValue;
                });
              },
            ),
            SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: selectedAchievement,
              decoration: InputDecoration(labelText: 'Next Major Achievement'),
              items: achievements.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Next major achievement is required';
                }
                return null;
              },
              onChanged: (String? newValue) {
                setState(() {
                  selectedAchievement = newValue!;
                  smeData['nextMajorAchievement'] = newValue;
                });
              },
            ),
            SizedBox(height: 16),
            TextFormField(
              initialValue: smeData['uniqueSellingProposition'] ?? '',
              maxLines: 3,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Unique Selling Proposition (USP)',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'USP is required';
                }
                return null;
              },
              onChanged: (value) => smeData['uniqueSellingProposition'] = value,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectorDropdown() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: DropdownButtonFormField<String>(
          value: selectedSector,
          decoration: InputDecoration(labelText: 'Sector'),
          items: sectors.map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value),
            );
          }).toList(),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Sector is required';
            }
            return null;
          },
          onChanged: (String? newValue) {
            setState(() {
              selectedSector = newValue!;
              smeData['sector'] = newValue;
            });
          },
        ),
      ),
    );
  }

  Widget _buildBusinessModelSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Business Model',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            Wrap(
              spacing: 8.0,
              children: businessModels.map((String model) {
                return FilterChip(
                  label: Text(model),
                  selected: smeData['businessModels']?.contains(model) ?? false,
                  onSelected: (bool selected) {
                    setState(() {
                      if (selected) {
                        smeData['businessModels'] = [
                          ...(smeData['businessModels'] ?? []),
                          model
                        ];
                      } else {
                        smeData['businessModels'] =
                            (smeData['businessModels'] as List)
                                .where((item) => item != model)
                                .toList();
                      }
                    });
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomersServedSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Customers Served',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal)),
            SizedBox(height: 16),
            TextFormField(
              initialValue: smeData['customersServed']?.toString() ?? '',
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Number of Customers Served',
                border: OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Number of customers served is required';
                }
                return null;
              },
              onChanged: (value) =>
                  smeData['customersServed'] = int.tryParse(value) ?? 0,
            ),
            SizedBox(height: 16),
            TextFormField(
              initialValue: smeData['b2bBusinessesServed']?.toString() ?? '',
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Number of B2B Businesses Served',
                border: OutlineInputBorder(),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Number of B2B businesses served is required';
                }
                return null;
              },
              onChanged: (value) =>
                  smeData['b2bBusinessesServed'] = int.tryParse(value) ?? 0,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveButton() {
    return ElevatedButton(
      child: Text('Save Changes'),
      onPressed: () => _showTermsAndConditions(),
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.symmetric(horizontal: 50, vertical: 20),
        textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  void _showTermsAndConditions() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        bool agreed = false;
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Terms and Conditions'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('By saving this information, you confirm that:'),
                  SizedBox(height: 10),
                  Text(
                      '1. All provided information is accurate to the best of your knowledge.'),
                  Text(
                      '2. You have the authority to share this information on behalf of your company.'),
                  Text(
                      '3. You agree to our terms of service and privacy policy.'),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Checkbox(
                        value: agreed,
                        onChanged: (bool? value) {
                          setState(() {
                            agreed = value!;
                          });
                        },
                      ),
                      Text('I agree to the terms and conditions'),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  child: Text('Cancel'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                ElevatedButton(
                  child: Text('Confirm and Save'),
                  onPressed: agreed
                      ? () {
                          Navigator.of(context).pop();
                          _saveData();
                        }
                      : null,
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildManagementTeam() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Management Team',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal)),
                ElevatedButton.icon(
                  icon: Icon(Icons.add),
                  label: Text('Add Member'),
                  onPressed: _addTeamMember,
                ),
              ],
            ),
            SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: managementTeam.length,
              itemBuilder: (context, index) {
                var member = managementTeam[index];
                return ListTile(
                  leading: CircleAvatar(
                    child: Text(member['name'][0]),
                  ),
                  title: Text(member['name']),
                  subtitle: Text(member['position']),
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () async {
                      User? user = _auth.currentUser;
                      if (user != null) {
                        await _firestore
                            .collection('smes')
                            .doc(user.uid)
                            .collection('management_team')
                            .doc(member['id'])
                            .delete();
                        _loadManagementTeam();
                      }
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(String label, String field, TextInputType inputType) {
    return TextFormField(
      initialValue: smeData[field] ?? '',
      keyboardType: inputType,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label is required';
        }
        return null;
      },
      onChanged: (value) => smeData[field] = value,
    );
  }
}
