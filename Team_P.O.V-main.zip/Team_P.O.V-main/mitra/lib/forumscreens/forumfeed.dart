import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'topicpage.dart'; // Import the Topics page
import 'forumpost.dart'; // Import the PostCard widget
import 'createpost.dart'; // Import the CreatePost widget

class ForumFeed extends StatelessWidget {
  const ForumFeed({super.key});

  @override
  Widget build(BuildContext context) {
    final String? currentUserId = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Followed Posts'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.topic),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        ForumTopicsPage()), // Navigate to TopicsPage
              );
            },
          ),
        ],
      ),
      body: currentUserId == null
          ? const Center(child: Text('User not logged in'))
          : StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(currentUserId)
                  .snapshots(),
              builder: (context, userSnapshot) {
                if (userSnapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (userSnapshot.hasError) {
                  return Center(child: Text('Error: ${userSnapshot.error}'));
                }
                if (!userSnapshot.data!.exists) {
                  return const Center(child: Text('User not found'));
                }

                List<dynamic> followedTopics =
                    userSnapshot.data!['followedTopics'] ?? [];

                if (followedTopics.isEmpty) {
                  return const Center(
                      child: Text('You are not following any topics.'));
                }

                return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('posts')
                      .where('topicId', whereIn: followedTopics)
                      .snapshots(),
                  builder: (context, postsSnapshot) {
                    if (postsSnapshot.connectionState ==
                        ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    if (postsSnapshot.hasError) {
                      return Center(
                          child: Text('Error: ${postsSnapshot.error}'));
                    }

                    final posts = postsSnapshot.data?.docs ?? [];

                    return ListView.builder(
                      itemCount: posts.length,
                      itemBuilder: (context, index) {
                        final post =
                            posts[index].data() as Map<String, dynamic>;

                        return PostCard(
                          title: post['title'],
                          content: post['content'],
                          investorId: post['investorId'],
                          timestamp: post['timestamp'],
                          postId: posts[index].id, // Pass the post ID here
                        );
                      },
                    );
                  },
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          // Fetch followed topics to pass to CreatePost
          final userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(currentUserId)
              .get();
          List<dynamic> followedTopics = userDoc['followedTopics'] ?? [];

          // Show CreatePost dialog
          showDialog(
            context: context,
            builder: (context) => CreatePost(
                topics:
                    List<String>.from(followedTopics)), // Pass followed topics
          );
        },
        tooltip: 'Create Post',
        child: const Icon(Icons.add),
      ),
    );
  }
}
