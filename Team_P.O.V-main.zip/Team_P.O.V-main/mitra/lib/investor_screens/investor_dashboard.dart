import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class InvestorDashboard extends StatefulWidget {
  const InvestorDashboard({super.key});

  @override
  _InvestorDashboardState createState() => _InvestorDashboardState();
}

class _InvestorDashboardState extends State<InvestorDashboard> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Map<String, dynamic> investorData = {};
  bool isLoading = true;

  List<String> investmentStages = [
    'Seed',
    'Early Stage',
    'Growth Stage',
    'Pre-IPO',
    'Series A',
    'Series B',
    'Series C+'
  ];

  List<String> investmentSectors = [
    'Technology',
    'Healthcare',
    'Finance',
    'Education',
    'E-commerce',
    'Manufacturing',
    'Clean Energy',
    'Agriculture'
  ];

  List<Map<String, dynamic>> portfolio = [];
  List<Map<String, dynamic>> investmentTeam = [];

  @override
  void initState() {
    super.initState();
    _loadInvestorData();
    _loadPortfolio();
    _loadInvestmentTeam();
  }

  Future<void> _loadInvestorData() async {
    setState(() => isLoading = true);

    User? user = _auth.currentUser;
    if (user != null) {
      DocumentSnapshot doc =
          await _firestore.collection('investors').doc(user.uid).get();
      if (doc.exists) {
        setState(() {
          investorData = doc.data() as Map<String, dynamic>;
          isLoading = false;
        });
      }
    }
    setState(() => isLoading = false);
  }

  Future<void> _loadPortfolio() async {
    User? user = _auth.currentUser;
    if (user != null) {
      QuerySnapshot portfolioSnapshot = await _firestore
          .collection('investors')
          .doc(user.uid)
          .collection('portfolio')
          .get();

      setState(() {
        portfolio = portfolioSnapshot.docs
            .map((doc) => doc.data() as Map<String, dynamic>)
            .toList();
      });
    }
  }

  Future<void> _loadInvestmentTeam() async {
    User? user = _auth.currentUser;
    if (user != null) {
      QuerySnapshot teamSnapshot = await _firestore
          .collection('investors')
          .doc(user.uid)
          .collection('investment_team')
          .get();

      setState(() {
        investmentTeam = teamSnapshot.docs
            .map((doc) => doc.data() as Map<String, dynamic>)
            .toList();
      });
    }
  }

  Future<void> _saveData() async {
    User? user = _auth.currentUser;
    if (user != null) {
      await _firestore
          .collection('investors')
          .doc(user.uid)
          .set(investorData, SetOptions(merge: true));
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Data saved successfully'),
        backgroundColor: Colors.green,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            SvgPicture.asset('assets/mitra_logo.svg',
                height: 24, color: Colors.white),
            const SizedBox(width: 8),
            const Text('Your Dashboard'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadInvestorData,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInvestorProfile(),
            const SizedBox(height: 20),
            _buildInvestmentOverview(),
            const SizedBox(height: 20),
            _buildInvestmentPreferences(),
            const SizedBox(height: 20),
            _buildPortfolioSection(),
            const SizedBox(height: 20),
            _buildInvestmentTeamSection(),
            const SizedBox(height: 20),
            _buildInvestmentCriteria(),
            const SizedBox(height: 20),
            _buildSaveButton(),
            _buildAdditionalFeatures(context),
          ],
        ),
      ),
    );
  }

  Widget _buildInvestorProfile() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  child: CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(
                        investorData['profileImageUrl'] ??
                            'https://via.placeholder.com/80'),
                    child: const Icon(Icons.camera_alt, color: Colors.white70),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        investorData['name'] ?? 'Investor Name',
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'ID: ${_auth.currentUser?.uid.substring(0, 8) ?? ''}',
                        style:
                            const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInvestmentOverview() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Investment Overview',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _buildMetricCard('Total Investment Capacity',
                    'totalInvestmentCapacity', Icons.account_balance),
                _buildMetricCard('Investments Made', 'totalInvestmentsMade',
                    Icons.show_chart),
                _buildMetricCard('Average Ticket Size', 'averageTicketSize',
                    Icons.monetization_on),
                _buildMetricCard('Number of Portfolio Companies',
                    'portfolioCompaniesCount', Icons.business),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricCard(String label, String field, IconData icon) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Card(
      color: Colors.white,
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 28, color: Colors.indigo),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueGrey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            TextFormField(
              initialValue:
                  formatter.format((investorData[field] ?? 0) / 100000),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.indigo[700]),
              decoration: const InputDecoration(
                prefixText: '₹ ',
                border: InputBorder.none,
              ),
              inputFormatters: [
                FilteringTextInputFormatter.allow(
                    RegExp(r'^\d{0,8}(\.\d{0,2})?$')),
              ],
              onChanged: (value) {
                value = value.replaceAll(RegExp(r'[^0-9.]'), '');
                double? parsedValue = double.tryParse(value);
                if (parsedValue != null) {
                  setState(() {
                    investorData[field] = parsedValue * 100000;
                  });
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBasicInformation() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          initialValue: investorData['description'] ?? '',
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'About the Investor/Firm',
            border: OutlineInputBorder(),
          ),
          onChanged: (value) => investorData['description'] = value,
        ),
        const SizedBox(height: 16),
        TextFormField(
          initialValue: investorData['website'] ?? '',
          decoration: const InputDecoration(
            labelText: 'Website',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.web),
          ),
          onChanged: (value) => investorData['website'] = value,
        ),
        ElevatedButton(
          onPressed: () async {},
          child: const Text('Visit Website'),
        ),
        const SizedBox(height: 16),
        TextFormField(
          initialValue: investorData['email'] ?? '',
          decoration: const InputDecoration(
            labelText: 'Contact Email',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.email),
          ),
          onChanged: (value) => investorData['email'] = value,
        ),
      ],
    );
  }
  Widget _buildAdditionalFeatures(BuildContext context) {
    final features = [
      {
        'icon': Icons.work_outline,
        'title': 'Hire Young Talents',
        'subtitle': 'Find skilled interns',
        'route': '/student-feed'
      },
    
      {
        'icon': Icons.sell,
        'title': 'WholeShale Market Place to Sell',
        'subtitle': 'Sell the raw material ',
        'route': '/product'
      },
      {
        'icon': Icons.place, 
        'title': 'WholeShale Market Place to Buy ',
        'subtitle': 'Buy the raw material',
        'route': '/list-product'
      }
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Explore More',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF003366),
          ),
        ),
        const SizedBox(height: 16),
        ...features.map((feature) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, feature['route'] as String);
                },
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blueGrey.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF003366).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          feature['icon'] as IconData,
                          color: const Color(0xFF003366),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            feature['title'] as String,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF003366),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            feature['subtitle'] as String,
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.blueGrey[300],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )),
      ],
    );
  }

  Widget _buildInvestmentPreferences() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Investment Preferences',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            const Text('Preferred Investment Stages',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8.0,
              children: investmentStages.map((String stage) {
                return FilterChip(
                  label: Text(stage),
                  selected:
                      investorData['preferredStages']?.contains(stage) ?? false,
                  onSelected: (bool selected) {
                    setState(() {
                      if (selected) {
                        investorData['preferredStages'] = [
                          ...(investorData['preferredStages'] ?? []),
                          stage
                        ];
                      } else {
                        investorData['preferredStages'] =
                            (investorData['preferredStages'] as List)
                                .where((item) => item != stage)
                                .toList();
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 16),
            const Text('Preferred Sectors',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Wrap(
              spacing: 8.0,
              children: investmentSectors.map((String sector) {
                return FilterChip(
                  label: Text(sector),
                  selected:
                      investorData['preferredSectors']?.contains(sector) ??
                          false,
                  onSelected: (bool selected) {
                    setState(() {
                      if (selected) {
                        investorData['preferredSectors'] = [
                          ...(investorData['preferredSectors'] ?? []),
                          sector
                        ];
                      } else {
                        investorData['preferredSectors'] =
                            (investorData['preferredSectors'] as List)
                                .where((item) => item != sector)
                                .toList();
                      }
                    });
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPortfolioSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Portfolio Companies',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.indigo)),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Add Company'),
                  onPressed: _addPortfolioCompany,
                ),
              ],
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: portfolio.length,
              itemBuilder: (context, index) {
                final company = portfolio[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                        company['logoUrl'] ?? 'https://via.placeholder.com/40'),
                    backgroundColor: Colors.grey[200],
                  ),
                  title: Text(company['name'] ?? ''),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(company['sector'] ?? ''),
                      Text(
                          'Investment: ₹${NumberFormat("#,##0.00", "en_IN").format(company['investmentAmount'] ?? 0)}'),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _deletePortfolioCompany(index),
                  ),
                  isThreeLine: true,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _addPortfolioCompany() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String name = '';
        String sector = '';
        double investmentAmount = 0;
        String stage = '';
        String exitStrategy = '';

        return AlertDialog(
          title: const Text('Add Portfolio Company'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: const InputDecoration(labelText: 'Company Name'),
                  onChanged: (value) => name = value,
                ),
                TextField(
                  decoration: const InputDecoration(labelText: 'Sector'),
                  onChanged: (value) => sector = value,
                ),
                TextField(
                  decoration: const InputDecoration(
                    labelText: 'Investment Amount (in Lakhs)',
                    prefixText: '₹',
                  ),
                  keyboardType: TextInputType.number,
                  onChanged: (value) =>
                      investmentAmount = double.tryParse(value) ?? 0,
                ),
                DropdownButtonFormField<String>(
                  decoration:
                      const InputDecoration(labelText: 'Investment Stage'),
                  items: investmentStages.map((stage) {
                    return DropdownMenuItem(
                      value: stage,
                      child: Text(stage),
                    );
                  }).toList(),
                  onChanged: (value) => stage = value ?? '',
                ),
                TextField(
                  decoration: const InputDecoration(labelText: 'Exit Strategy'),
                  onChanged: (value) => exitStrategy = value,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Add'),
              onPressed: () async {
                if (name.isNotEmpty && sector.isNotEmpty) {
                  User? user = _auth.currentUser;
                  if (user != null) {
                    await _firestore
                        .collection('investors')
                        .doc(user.uid)
                        .collection('portfolio')
                        .add({
                      'name': name,
                      'sector': sector,
                      'investmentAmount': investmentAmount * 100000,
                      'stage': stage,
                      'exitStrategy': exitStrategy,
                      'dateAdded': DateTime.now(),
                    });
                    _loadPortfolio();
                    Navigator.of(context).pop();
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _deletePortfolioCompany(int index) async {
    User? user = _auth.currentUser;
    if (user != null) {
      await _firestore
          .collection('investors')
          .doc(user.uid)
          .collection('portfolio')
          .doc(portfolio[index]['id'])
          .delete();
      setState(() {
        portfolio.removeAt(index);
      });
    }
  }

  Widget _buildInvestmentTeamSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Investment Team',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.indigo)),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: const Text('Add Member'),
                  onPressed: _addTeamMember,
                ),
              ],
            ),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: investmentTeam.length,
              itemBuilder: (context, index) {
                final member = investmentTeam[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.indigo,
                    child: Text(member['name'][0]),
                  ),
                  title: Text(member['name']),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(member['position']),
                      Text(member['expertise']),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _deleteTeamMember(index),
                  ),
                  isThreeLine: true,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _addTeamMember() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        String name = '';
        String position = '';
        String expertise = '';
        String linkedinUrl = '';

        return AlertDialog(
          title: const Text('Add Team Member'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: const InputDecoration(labelText: 'Name'),
                  onChanged: (value) => name = value,
                ),
                TextField(
                  decoration: const InputDecoration(labelText: 'Position'),
                  onChanged: (value) => position = value,
                ),
                TextField(
                  decoration: const InputDecoration(labelText: 'Expertise'),
                  onChanged: (value) => expertise = value,
                ),
                TextField(
                  decoration: const InputDecoration(labelText: 'LinkedIn URL'),
                  onChanged: (value) => linkedinUrl = value,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Add'),
              onPressed: () async {
                if (name.isNotEmpty && position.isNotEmpty) {
                  User? user = _auth.currentUser;
                  if (user != null) {
                    await _firestore
                        .collection('investors')
                        .doc(user.uid)
                        .collection('investment_team')
                        .add({
                      'name': name,
                      'position': position,
                      'expertise': expertise,
                      'linkedinUrl': linkedinUrl,
                    });
                    _loadInvestmentTeam();
                    Navigator.of(context).pop();
                  }
                }
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteTeamMember(int index) async {
    User? user = _auth.currentUser;
    if (user != null) {
      await _firestore
          .collection('investors')
          .doc(user.uid)
          .collection('investment_team')
          .doc(investmentTeam[index]['id'])
          .delete();
      setState(() {
        investmentTeam.removeAt(index);
      });
    }
  }

  Widget _buildInvestmentCriteria() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Investment Criteria',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: investorData['minimumRevenue']?.toString() ?? '',
              decoration: const InputDecoration(
                labelText: 'Minimum Revenue Requirement (in Lakhs)',
                border: OutlineInputBorder(),
                prefixText: '₹',
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) =>
                  investorData['minimumRevenue'] = double.tryParse(value) ?? 0,
            ),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: investorData['minimumTicketSize']?.toString() ?? '',
              decoration: const InputDecoration(
                labelText: 'Minimum Ticket Size (in Lakhs)',
                border: OutlineInputBorder(),
                prefixText: '₹',
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) => investorData['minimumTicketSize'] =
                  double.tryParse(value) ?? 0,
            ),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: investorData['maximumTicketSize']?.toString() ?? '',
              decoration: const InputDecoration(
                labelText: 'Maximum Ticket Size (in Lakhs)',
                border: OutlineInputBorder(),
                prefixText: '₹',
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) => investorData['maximumTicketSize'] =
                  double.tryParse(value) ?? 0,
            ),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: investorData['expectedROI']?.toString() ?? '',
              decoration: const InputDecoration(
                labelText: 'Expected ROI (%)',
                border: OutlineInputBorder(),
                suffixText: '%',
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) =>
                  investorData['expectedROI'] = double.tryParse(value) ?? 0,
            ),
            const SizedBox(height: 16),
            TextFormField(
              initialValue: investorData['investmentThesis'] ?? '',
              decoration: const InputDecoration(
                labelText: 'Investment Thesis',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
              onChanged: (value) => investorData['investmentThesis'] = value,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSaveButton() {
    return Center(
      child: ElevatedButton(
        onPressed: () => _showTermsAndConditions(),
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
          child: Text(
            'Save Changes',
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }

  Future<void> _uploadProfilePhoto() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      File file = File(image.path);
      User? user = _auth.currentUser;

      if (user != null) {
        try {
          TaskSnapshot snapshot = await _storage
              .ref('investor_profiles/${user.uid}.jpg')
              .putFile(file);

          String downloadUrl = await snapshot.ref.getDownloadURL();

          await _firestore.collection('investors').doc(user.uid).update({
            'profileUrl': downloadUrl,
          });

          setState(() {
            investorData['profileUrl'] = downloadUrl;
          });

          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Profile photo updated successfully'),
            backgroundColor: Colors.green,
          ));
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Failed to update profile photo'),
            backgroundColor: Colors.red,
          ));
        }
      }
    }
  }

  void _showTermsAndConditions() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        bool agreed = false;
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Terms and Conditions'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('By saving this information, you confirm that:'),
                  const SizedBox(height: 10),
                  const Text(
                      '1. All provided information is accurate and up-to-date.'),
                  const Text(
                      '2. You have the authority to represent this investment firm.'),
                  const Text(
                      '3. You agree to our terms of service and privacy policy.'),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Checkbox(
                        value: agreed,
                        onChanged: (bool? value) {
                          setState(() {
                            agreed = value!;
                          });
                        },
                      ),
                      const Expanded(
                        child: Text('I agree to the terms and conditions'),
                      ),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  child: const Text('Cancel'),
                  onPressed: () => Navigator.of(context).pop(),
                ),
                ElevatedButton(
                  onPressed: agreed
                      ? () {
                          Navigator.of(context).pop();
                          _saveData();
                        }
                      : null,
                  child: Text('Confirm and Save'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
