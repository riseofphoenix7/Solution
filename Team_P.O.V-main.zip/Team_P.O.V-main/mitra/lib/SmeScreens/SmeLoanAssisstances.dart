import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:mitra/jitsimeet/meetscheduler.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SME Student Feed',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: const StudentSmeFeeds(),
    );
  }
}

class StudentSmeFeeds extends StatelessWidget {
  const StudentSmeFeeds({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SME Student Feed',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue[700],
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('students').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No students found'));
          }
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var studentDoc = snapshot.data!.docs[index];
              var student = studentDoc.data() as Map<String, dynamic>;
              return StudentCard(student: student, studentId: studentDoc.id);
            },
          );
        },
      ),
    );
  }
}

class StudentCard extends StatelessWidget {
  final Map<String, dynamic> student;
  final String studentId;

  const StudentCard(
      {super.key, required this.student, required this.studentId});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) =>
                  DetailedStudentView(student: student, studentId: studentId)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(student['photoUrl'] ??
                        'https://via.placeholder.com/60'),
                    radius: 30,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          student['name'] ?? 'Student Name',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        Text(student['university'] ?? 'University',
                            style: TextStyle(color: Colors.grey[600])),
                        const SizedBox(height: 4),
                        Text(student['major'] ?? 'Major',
                            style: TextStyle(color: Colors.blue[700])),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                student['desiredRole'] ?? 'Desired Role: Not specified',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: (student['skills'] as Map<String, dynamic>? ?? {})
                    .entries
                    .expand((entry) => entry.value.map<Widget>((skill) => Chip(
                          label: Text(skill),
                          backgroundColor: Colors.blue[100],
                          labelStyle: TextStyle(color: Colors.blue[700]),
                        )))
                    .toList()
                    .cast<Widget>(),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildIconButton(Icons.email, 'Email',
                      () => _launchEmail(student['email'])),
                  _buildIconButton(
                      Icons.video_call,
                      'Video Chat',
                      () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => MeetScheduler(
                                targetUser: studentId, // Pass student ID here
                              ),
                            ),
                          )),
                  _buildIconButton(Icons.message, 'Message',
                      () => _launchMessage(student['phone'])),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: Colors.blue[700]),
          onPressed: onPressed,
        ),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  void _launchEmail(String? email) async {
    if (email != null) {
      final Uri emailLaunchUri = Uri(scheme: 'mailto', path: email);
      if (await canLaunchUrl(emailLaunchUri)) {
        await launchUrl(emailLaunchUri);
      }
    }
  }

  void _launchMessage(String? phone) async {
    if (phone != null) {
      final Uri smsLaunchUri = Uri(scheme: 'sms', path: phone);
      if (await canLaunchUrl(smsLaunchUri)) {
        await launchUrl(smsLaunchUri);
      }
    }
  }
}

class DetailedStudentView extends StatelessWidget {
  final Map<String, dynamic> student;
  final String studentId;

  const DetailedStudentView(
      {super.key, required this.student, required this.studentId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(student['name'] ?? 'Student Details'),
        backgroundColor: Colors.blue[700],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                backgroundImage: NetworkImage(
                    student['photoUrl'] ?? 'https://via.placeholder.com/120'),
                radius: 60,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              student['name'] ?? 'Student Name',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              student['university'] ?? 'University',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            _buildInfoCard('Student Overview', [
              _buildInfoRow('Major', student['major'] ?? 'N/A'),
              _buildInfoRow('Desired Role', student['desiredRole'] ?? 'N/A'),
              _buildInfoRow('GPA', student['gpa']?.toString() ?? 'N/A'),
              _buildInfoRow('Graduation Year',
                  student['graduationYear']?.toString() ?? 'N/A'),
            ]),
            const SizedBox(height: 16),
            _buildInfoCard('Contact Information', [
              _buildInfoRow('Email', student['email'] ?? 'N/A'),
              _buildInfoRow('Phone', student['phone'] ?? 'N/A'),
            ]),
            const SizedBox(height: 24),
            const Text('Skills',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...(student['skills'] as Map<String, dynamic>? ?? {})
                .entries
                .map((entry) => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(entry.key,
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue[700])),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          children: (entry.value as List<dynamic>)
                              .map((skill) => Chip(
                                    label: Text(skill),
                                    backgroundColor: Colors.blue[100],
                                    labelStyle:
                                        TextStyle(color: Colors.blue[700]),
                                  ))
                              .toList(),
                        ),
                        const SizedBox(height: 16),
                      ],
                    )),
            const SizedBox(height: 24),
            const Text('Projects',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...(student['projects'] as List<dynamic>? ?? [])
                .map((project) => Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(project['name'] ?? 'Project Name',
                                style: const TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold)),
                            const SizedBox(height: 8),
                            Text(
                                project['description'] ?? 'Project Description',
                                style: TextStyle(color: Colors.grey[600])),
                          ],
                        ),
                      ),
                    ))
                .toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value),
        ],
      ),
    );
  }
}
