import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  ProfileScreenState createState() => ProfileScreenState();
}

class ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _investmentExperienceController =
      TextEditingController();
  final TextEditingController _preferredIndustriesController =
      TextEditingController();
  final TextEditingController _investmentRangeController =
      TextEditingController();
  final TextEditingController _exitStrategyController = TextEditingController();
  final TextEditingController _riskToleranceController =
      TextEditingController();
  Map<String, dynamic> preferences = {};
  bool isLoading = false;
  String? imageUrl;
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    _fetchUserProfile();
  }

  Future getImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      await uploadImage(image.path);
    }
  }

  Future uploadImage(String filePath) async {
    const apiKey = '52f71e0a2799ca4c9bee3ef6644a3560';
    final url = Uri.parse('https://api.imgbb.com/1/upload');

    try {
      var request = http.MultipartRequest('POST', url)
        ..fields['key'] = apiKey
        ..files.add(await http.MultipartFile.fromPath('image', filePath));

      var response = await request.send();
      var responseData = await response.stream.toBytes();
      var result = json.decode(String.fromCharCodes(responseData));

      if (response.statusCode == 200) {
        setState(() {
          imageUrl = result['data']['url'];
        });
        await saveUrlToFirestore();
      } else {
        print('Failed to upload image. Status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception occurred during image upload: $e');
    }
  }

  Future saveUrlToFirestore() async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null && imageUrl != null) {
        await FirebaseFirestore.instance.collection('smes').doc(uid).set({
          'profileImageUrl': imageUrl,
        }, SetOptions(merge: true));
      }
    } catch (e) {
      print('Exception occurred while saving to Firestore: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: ThemeData(
        primarySwatch: Colors.teal,
        hintColor: Colors.green,
        buttonTheme: const ButtonThemeData(buttonColor: Colors.teal),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
        ),
      ),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Profile'),
          backgroundColor: Colors.teal,
        ),
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.teal)))
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildNameBioCard(),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildNameBioCard() {
    return Column(
      children: [
        Card(
          elevation: 4,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                GestureDetector(
                  onTap: getImage,
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage:
                        imageUrl != null ? NetworkImage(imageUrl!) : null,
                    backgroundColor: Colors.teal.shade100,
                    child: imageUrl == null
                        ? const Icon(Icons.person, size: 50, color: Colors.teal)
                        : null,
                  ),
                ),
                const SizedBox(height: 16),
                isEditing ? _buildNameBioForm() : _buildNameBioDisplay(),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _fetchUserProfile() async {
    setState(() {
      isLoading = true;
    });
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      try {
        DocumentSnapshot userProfile = await FirebaseFirestore.instance
            .collection('investors')
            .doc(uid)
            .get();
        if (userProfile.exists) {
          setState(() {
            _nameController.text = userProfile.get('name') ?? '';
            _bioController.text = userProfile.get('bio') ?? '';
            _investmentExperienceController.text =
                userProfile.get('investmentExperience') ?? '';
            _preferredIndustriesController.text =
                userProfile.get('preferredIndustries') ?? '';
            _investmentRangeController.text =
                userProfile.get('investmentRange') ?? '';
            _exitStrategyController.text =
                userProfile.get('exitStrategy') ?? '';
            _riskToleranceController.text =
                userProfile.get('riskTolerance') ?? '';
            imageUrl = userProfile.get('profileImageUrl');
            preferences =
                userProfile.get('Preferences') as Map<String, dynamic>? ?? {};
            isEditing =
                _nameController.text.isEmpty || _bioController.text.isEmpty;
          });
        } else {
          setState(() {
            isEditing = true;
          });
        }
      } catch (e) {
        print('Error fetching user profile: $e');
      }
    }
    setState(() {
      isLoading = false;
    });
  }

  Future<void> _saveUserProfile() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      if (_nameController.text.trim().isEmpty ||
          _bioController.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Name and Bio are required!'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
      try {
        await FirebaseFirestore.instance.collection('investors').doc(uid).set({
          'name': _nameController.text.trim(),
          'bio': _bioController.text.trim(),
          'investmentExperience': _investmentExperienceController.text.trim(),
          'preferredIndustries': _preferredIndustriesController.text.trim(),
          'investmentRange': _investmentRangeController.text.trim(),
          'exitStrategy': _exitStrategyController.text.trim(),
          'riskTolerance': _riskToleranceController.text.trim(),
        }, SetOptions(merge: true));
        setState(() {
          isEditing = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Profile Saved!'), backgroundColor: Colors.teal),
        );
      } catch (e) {
        print('Error saving user profile: $e');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Failed to save profile. Please try again.'),
              backgroundColor: Colors.red),
        );
      }
    }
  }

  Widget _buildNameBioForm() {
    return Column(
      children: [
        TextField(
          controller: _nameController,
          maxLength: 30,
          decoration: const InputDecoration(
            labelText: 'Name',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _bioController,
          maxLength: 100,
          decoration: const InputDecoration(
            labelText: 'Bio',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
          maxLines: 3,
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _investmentExperienceController,
          decoration: const InputDecoration(
            labelText: 'Investment Experience (years)',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _preferredIndustriesController,
          decoration: const InputDecoration(
            labelText: 'Preferred Industries',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _investmentRangeController,
          decoration: const InputDecoration(
            labelText: 'Investment Range',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _exitStrategyController,
          decoration: const InputDecoration(
            labelText: 'Exit Strategy',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _riskToleranceController,
          decoration: const InputDecoration(
            labelText: 'Risk Tolerance',
            labelStyle: TextStyle(color: Colors.teal),
            focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.teal)),
          ),
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _saveUserProfile,
          child: const Text('Save Profile'),
        ),
      ],
    );
  }

  Widget _buildNameBioDisplay() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Name: ${_nameController.text}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          'Bio: ${_bioController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 8),
        Text(
          'Investment Experience: ${_investmentExperienceController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 8),
        Text(
          'Preferred Industries: ${_preferredIndustriesController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 8),
        Text(
          'Investment Range: ${_investmentRangeController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 8),
        Text(
          'Exit Strategy: ${_exitStrategyController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 8),
        Text(
          'Risk Tolerance: ${_riskToleranceController.text}',
          style: const TextStyle(fontSize: 16),
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: () {
            setState(() {
              isEditing = true;
            });
          },
          child: const Text('Edit Profile'),
        ),
      ],
    );
  }
}
