import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'student_profile_page.dart';
import 'dart:io';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Dashboard',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: StudentDashboard(),
    );
  }
}

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  _StudentDashboardState createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Map<String, dynamic> studentData = {};
  bool isLoading = true;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController majorController = TextEditingController();
  TextEditingController universityController = TextEditingController();
  TextEditingController gpaController = TextEditingController();
  TextEditingController graduationYearController = TextEditingController();
  TextEditingController roleController = TextEditingController();

  List<String> skillCategories = [
    'Marketing',
    'Designing',
    'Technology',
    'Logistics',
    'Other'
  ];
  Map<String, List<String>> skills = {
    'Marketing': [],
    'Designing': [],
    'Technology': [],
    'Logistics': [],
    'Other': [],
  };

  List<Map<String, String>> projects = [];

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  Future<void> _loadStudentData() async {
    setState(() => isLoading = true);

    User? user = _auth.currentUser;
    if (user != null) {
      DocumentSnapshot doc =
          await _firestore.collection('students').doc(user.uid).get();
      if (doc.exists) {
        setState(() {
          studentData = doc.data() as Map<String, dynamic>;
          _populateControllers();
          _populateSkills();
          _populateProjects();
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _populateControllers() {
    nameController.text = studentData['name'] ?? '';
    emailController.text = studentData['email'] ?? '';
    phoneController.text = studentData['phone'] ?? '';
    majorController.text = studentData['major'] ?? '';
    universityController.text = studentData['university'] ?? '';
    gpaController.text = studentData['gpa']?.toString() ?? '';
    graduationYearController.text =
        studentData['graduationYear']?.toString() ?? '';
    roleController.text = studentData['desiredRole'] ?? '';
  }

  void _populateSkills() {
    if (studentData['skills'] != null) {
      Map<String, dynamic> skillsData = studentData['skills'];
      for (var category in skillCategories) {
        if (skillsData[category] != null) {
          skills[category] = List<String>.from(skillsData[category]);
        }
      }
    }
  }

  void _populateProjects() {
    if (studentData['projects'] != null) {
      projects = List<Map<String, String>>.from(studentData['projects']);
    }
  }

  Future<void> _saveData() async {
    User? user = _auth.currentUser;
    if (user != null) {
      await _firestore.collection('students').doc(user.uid).set({
        'name': nameController.text,
        'email': emailController.text,
        'phone': phoneController.text,
        'major': majorController.text,
        'university': universityController.text,
        'gpa': double.tryParse(gpaController.text) ?? 0.0,
        'graduationYear': int.tryParse(graduationYearController.text) ?? 0,
        'desiredRole': roleController.text,
        'skills': skills,
        'projects': projects,
      }, SetOptions(merge: true));

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Data saved successfully'),
        backgroundColor: Colors.green,
      ));
    }
  }

  Future<void> _uploadProfilePhoto() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      File file = File(image.path);
      User? user = _auth.currentUser;

      if (user != null) {
        try {
          TaskSnapshot snapshot = await _storage
              .ref('profile_photos/${user.uid}.jpg')
              .putFile(file);

          String downloadUrl = await snapshot.ref.getDownloadURL();

          await _firestore.collection('students').doc(user.uid).update({
            'photoUrl': downloadUrl,
          });

          setState(() {
            studentData['photoUrl'] = downloadUrl;
          });

          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Profile photo updated successfully'),
            backgroundColor: Colors.green,
          ));
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Failed to update profile photo'),
            backgroundColor: Colors.red,
          ));
        }
      }
    }
  }

  void _showAddSkillDialog(String category) {
    String newSkill = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Add $category Skill'),
          content: TextField(
            decoration: const InputDecoration(labelText: 'Skill Name'),
            onChanged: (value) => newSkill = value,
          ),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Add'),
              onPressed: () {
                if (newSkill.isNotEmpty) {
                  setState(() {
                    skills[category]!.add(newSkill);
                  });
                  _saveData();
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _showAddProjectDialog() {
    String projectName = '';
    String projectDescription = '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add Project'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                decoration: const InputDecoration(labelText: 'Project Name'),
                onChanged: (value) => projectName = value,
              ),
              TextField(
                decoration: const InputDecoration(
                    labelText:
                        'Project Description with github or drployrd url'),
                maxLines: 3,
                onChanged: (value) => projectDescription = value,
              ),
            ],
          ),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            ElevatedButton(
              child: const Text('Add'),
              onPressed: () {
                if (projectName.isNotEmpty && projectDescription.isNotEmpty) {
                  setState(() {
                    projects.add({
                      'name': projectName,
                      'description': projectDescription,
                    });
                  });
                  _saveData();
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadStudentData,
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              elevation: 0,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => InternshipListingsWidget()),
              );
            },
            child: Text('View Oppurunities'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildPersonalInformation(),
            const SizedBox(height: 20),
            _buildAcademicInformation(),
            const SizedBox(height: 20),
            _buildSkillsSection(),
            const SizedBox(height: 20),
            _buildProjectsSection(),
            const SizedBox(height: 20),
            _buildSaveButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Colors.indigo, Colors.indigoAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: _uploadProfilePhoto,
                  child: CircleAvatar(
                    radius: 40,
                    backgroundImage: NetworkImage(studentData['photoUrl'] ??
                        'https://via.placeholder.com/80'),
                    child: const Icon(Icons.camera_alt, color: Colors.white70),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        studentData['name'] ?? 'Student Name',
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                      Text(
                        'ID: ${_auth.currentUser?.uid.substring(0, 8) ?? ''}',
                        style: const TextStyle(
                            fontSize: 14, color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        studentData['university'] ?? 'University',
                        style:
                            const TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: roleController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Desired Role',
                labelStyle: TextStyle(color: Colors.white70),
                border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white)),
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white70)),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInformation() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Personal Information',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            _buildTextField('Name', nameController, TextInputType.name),
            _buildTextField(
                'Email', emailController, TextInputType.emailAddress),
            _buildTextField('Phone', phoneController, TextInputType.phone),
          ],
        ),
      ),
    );
  }

  Widget _buildAcademicInformation() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Academic Information',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            _buildTextField('Major', majorController, TextInputType.text),
            _buildTextField(
                'University', universityController, TextInputType.text),
            _buildTextField('GPA', gpaController, TextInputType.number),
            _buildTextField('Graduation Year', graduationYearController,
                TextInputType.number),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillsSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Skills',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo)),
            const SizedBox(height: 16),
            ...skillCategories.map((category) => _buildSkillCategory(category)),
          ],
        ),
      ),
    );
  }

  Widget _buildSkillCategory(String category) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(category,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo[700])),
            IconButton(
              icon: const Icon(Icons.add, color: Colors.amber),
              onPressed: () => _showAddSkillDialog(category),
            ),
          ],
        ),
        Wrap(
          spacing: 8,
          children: skills[category]!
              .map((skill) => Chip(
                    label: Text(skill),
                    backgroundColor: Colors.amber[100],
                  ))
              .toList(),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildProjectsSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Projects',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.indigo)),
                IconButton(
                  icon: const Icon(Icons.add, color: Colors.amber),
                  onPressed: _showAddProjectDialog,
                ),
              ],
            ),
            const SizedBox(height: 16),
            ...projects.map((project) => _buildProjectItem(project)),
          ],
        ),
      ),
    );
  }

  Widget _buildProjectItem(Map<String, String> project) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: ListTile(
        title: Text(project['name'] ?? '',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(project['description'] ?? ''),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.red),
          onPressed: () {
            setState(() {
              projects.remove(project);
            });
            _saveData();
          },
        ),
      ),
    );
  }

  Widget _buildTextField(
      String label, TextEditingController controller, TextInputType inputType) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        keyboardType: inputType,
      ),
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _saveData,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text('Save All Changes', style: TextStyle(fontSize: 18)),
        ),
      ),
    );
  }
}
