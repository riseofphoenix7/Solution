import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class SearchResultScreen extends StatefulWidget {
  final String searchTerm;

  const SearchResultScreen({super.key, required this.searchTerm});

  @override
  _SearchResultScreenState createState() => _SearchResultScreenState();
}

class _SearchResultScreenState extends State<SearchResultScreen> {
  List<Map<String, dynamic>> _investors = [];
  bool _isLoading = true;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  String? imageUrl;
  Map<String, dynamic> preferences = {};
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    _fetchUserProfile();
    _searchInvestors();
  }

  Future<void> _fetchUserProfile() async {
    setState(() {
      _isLoading = true;
    });
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      try {
        DocumentSnapshot userProfile =
            await FirebaseFirestore.instance.collection('smes').doc(uid).get();
        if (userProfile.exists) {
          setState(() {
            _nameController.text = userProfile.get('companyName') ?? '';
            _bioController.text = userProfile.get('bio') ?? '';
            imageUrl = userProfile.get('profileImageUrl');

            preferences = {
              'cashFlow': userProfile.get('cashFlow') ?? 0,
              'companyName': userProfile.get('companyName') ?? '',
              'employeeCount': userProfile.get('employeeCount') ?? 0,
              'fundingNeeds': userProfile.get('fundingNeeds') ?? 0,
              'logoUrl': userProfile.get('logoUrl') ?? '',
              'profit': userProfile.get('profit') ?? 0,
              'revenue': userProfile.get('revenue') ?? 0,
              'sector': userProfile.get('sector') ?? '',
              'valuation': userProfile.get('valuation') ?? 0,
            };
            isEditing =
                _nameController.text.isEmpty || _bioController.text.isEmpty;
          });
        } else {
          setState(() {
            isEditing = true;
          });
        }
      } catch (e) {
        print('Error fetching user profile: $e');
      }
    }
    setState(() {
      _isLoading = false;
    });
  }

  void _searchInvestors() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance.collection('smes').get();

      List<Map<String, dynamic>> tempInvestors = [];

      for (var doc in querySnapshot.docs) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        if (data['companyName'] != null &&
            data['companyName']
                .toLowerCase()
                .contains(widget.searchTerm.toLowerCase())) {
          tempInvestors.add({
            'uid': doc.id,
            'name': data['companyName'], // Fixed typo
            'bio': data['companyDescription'] ??
                'No bio available', // Updated bio source
            'profileImageUrl': data['profileImageUrl'],
          });
        }
      }

      setState(() {
        _investors = tempInvestors;
        _isLoading = false;
      });
    } catch (e) {
      print('Error fetching investors: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: _buildSearchBar(context),
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.teal))
          : _investors.isEmpty
              ? Center(
                  child: Text(
                  'No investors found for "${widget.searchTerm}"',
                  style: const TextStyle(color: Colors.teal),
                ))
              : ListView.builder(
                  itemCount: _investors.length,
                  itemBuilder: (context, index) {
                    final investor = _investors[index];
                    return profileCard(context, investor);
                  },
                ),
    );
  }

  Widget profileCard(BuildContext context, Map<String, dynamic> investor) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      elevation: 8,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Stack(
        children: [
          // Gradient background
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.green.shade400, Colors.teal.shade700],
              ),
            ),
          ),
          // Content
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      backgroundImage: investor['profileImageUrl'] != null
                          ? NetworkImage(investor['profileImageUrl'])
                          : null,
                      child: investor['profileImageUrl'] == null
                          ? Text(
                              investor['companyName']?[0]?.toUpperCase() ?? 'U',
                              style: TextStyle(
                                  fontSize: 24, color: Colors.teal.shade800),
                            )
                          : null,
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            investor['CompanyName'] ?? 'Unnamed Investor',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: Colors.teal.shade800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    investor['companyDescription'] ?? 'No bio available',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.green.shade800,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        // TODO: Implement view profile action
                      },
                      icon: Icon(Icons.person, color: Colors.teal.shade800),
                      label: Text('View Profile',
                          style: TextStyle(color: Colors.teal.shade800)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: TextField(
        decoration: InputDecoration(
          icon: const Icon(Icons.search, color: Colors.white),
          hintText: 'Search Investors...',
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
          border: InputBorder.none,
        ),
        style: const TextStyle(color: Colors.white),
        onSubmitted: (query) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SearchResultScreen(searchTerm: query),
            ),
          );
        },
      ),
    );
  }
}
