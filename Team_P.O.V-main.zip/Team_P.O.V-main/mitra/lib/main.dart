import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:jitsi_meet_flutter_sdk/jitsi_meet_flutter_sdk.dart';
import 'package:mitra/SmeScreens/SMEdashboard.dart';
import 'package:mitra/SmeScreens/SmeCalculator.dart';
import 'package:mitra/SmeScreens/SmeChatbot.dart';
import 'package:mitra/SmeScreens/SmeInvestorFeed.dart';
import 'package:mitra/SmeScreens/SmeLoanAssisstances.dart';
import 'package:mitra/SmeScreens/SmeMentorship.dart';
import 'package:mitra/SmeScreens/Smeforums.dart';
import 'package:mitra/SmeScreens/smehomepage.dart';
import 'package:mitra/investor_screens/investor_dashboard.dart';
import 'package:mitra/investor_screens/smefeed.dart';
import 'package:mitra/jitsimeet/jitsimeet.dart';
import 'package:mitra/marketplace/sme_listings.dart';
import 'package:mitra/forumscreens/forumfeed.dart';
import 'package:mitra/signIn-UpScreen/sign_in_screen.dart';
import 'firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'investor_screens/latest_news.dart';
import 'forumscreens/topicpage.dart';
import 'forumscreens/forumfeed.dart';
import 'investor_screens/investor_dashboard.dart';
import 'SmeScreens/find_investors.dart';
import 'jitsimeet/meetscheduler.dart';
import 'SmeScreens/SmeInvestorFeed.dart';
import 'jitsimeet/meetings.dart';
import 'SmeScreens/SMEdashboard.dart';
import 'studentScreen/student_landing.dart';
import 'SmeScreens/SmeLoanAssisstances.dart';
import 'investor_screens/latest_news.dart';
import 'package:mitra/marketbase/marketbase.dart';
import 'package:mitra/marketbase/listproduct.dart';
import './investor_screens/find_smes.dart';
import './SmeScreens/SmeLoanAssisstances.dart';
import '../SmeScreens/search_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  final uid = FirebaseAuth.instance.currentUser?.uid;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Project MITRA',
      theme: ThemeData(primarySwatch: Colors.lightBlue),
      initialRoute: '/',
      routes: {
        '/': (context) => const AuthGate(),
        '/home': (context) => const Smehomepage(),
        '/dashboard': (context) => SMEDashboard(),
        '/investor-feed': (context) => const SmeInvestorFeed(),
        '/calculator': (context) => const SmeCalculator(),
        '/chatbot': (context) => const Smechatbot(),
        '/forums': (context) => const ForumFeed(),
        '/product': (context) => ListNewProduct(),
        '/news': (context) => const NewsScreen(),
        '/forums': (context) => ForumTopicsPage(),
        '/mentorship': (context) => const Smementorship(),
        '/listing': (context) => SMEListScreen(smeId: uid ?? ''),
        '/forum-feed': (context) => const ForumFeed(),
        '/dashboard': (context) => InvestorDashboard(),
        '/sme-feed': (context) => Smefeeds(),
        '/find-investors': (context) => InvestorFeed(),
        '/meet-scheduler': (context) => MeetScheduler(targetUser: uid ?? ''),
        '/meetings': (context) => const JitsiMeetScreen(
              title: "schedule a meeting",
            ),
        '/dash': (context) => SMEDashboard(),
        '/signin': (context) => const SignInScreen(),
        '/find-investors': (context) => InvestorFeed(),
        '/list-product': (context) => ViewProducts(),
        '/student-feed': (context) => sme_feed(),
        '/searchinvestors': (context) => SearchResultScreen(searchTerm: ''),
      },
      onUnknownRoute: (settings) {
        return MaterialPageRoute(
          builder: (context) => const Smehomepage(),
        );
      },
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else {
          return const SignInScreen(); // User is not logged in
        }
      },
    );
  }
}

// Optional: Add a route guard to protect authenticated routes
class RouteGuard extends StatelessWidget {
  final Widget child;

  const RouteGuard({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasData) {
          return child;
        } else {
          return const SignInScreen();
        }
      },
    );
  }
}
