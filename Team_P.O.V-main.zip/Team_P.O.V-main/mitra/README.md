# Manipal Hackathon 2024 README Template

**Team Name:** `Team POV`

**Problem Statement:** `Empowering SMEs for Resource Access, Networking, and Growth`

## 📜 Introduction

Our project allows investors to connect with small and medium enterprises (SMEs) through voice and video calls, access the latest financial news, and create product listings, while SMEs can use the platform to connect with investors, calculate their finances, and engage with forums to find communities and post ads. We have utilized Flutter, Firebase, and the Jitsi Meet API to build a seamless experience that includes tailored profiles, landing screens, and a search function, enabling efficient networking, communication, and collaboration between investors and SMEs.

## ✨ Features

- **Voice and Video Calls:** Investors and SMEs can connect via seamless voice and video calls using the Jitsi Meet API.
- **Multiple User Logins:** Separate logins for investors and SMEs with dedicated landing screens and profiles.
- **Search Functionality:** Each user type can search for the other using a simple search button on their landing screens.
- **SME Financial Calculator:** A built-in financial calculator for SMEs to manage their finances.
- **Investor News Feed:** Latest financial news curated for investors to stay informed.
- **Community Forums:** Forums where both investors and SMEs can engage, create posts, and find like-minded communities.
- **SME Ad Posting:** SMEs can create ads and posts to promote their products or services.
- **Investor Product Listings:** Investors can create listings for products to sell or promote.
- **Seamless Profile Management:** Tailored profiles for investors and SMEs with easy editing and management options.
- **Secure Authentication:** Firebase authentication ensuring secure login for both investors and SMEs.
- **Real-time Data:** Data syncing and updates in real-time using Firebase Firestore.
- **User Notifications:** Push notifications for important updates, calls, and messages.
- **Loan Assistance Chatbot:** AI-powered chatbots trained on patented datasets and textbooks to assist SMEs with loan applications and financial advice.


## 🟢 Access

🌐 Website link: https://example.com

📱 App's APK file location: [`android/build/my-app.apk`](android/build/my-app.apk)

OR

📱 Play store link: https://play.google.com/store/apps/details?id=com.digilocker.android


## ⚙️ Instructions For Local Deployment 

Follow these steps to run the project locally:

### Clone the repository
Open a terminal and run the following command:

```bash
git clone <repository-url>
cd <project-directory>
```

### Install Flutter dependencies
Make sure Flutter is installed. Then, inside the project directory, run:

```bash
flutter pub get
```

### Set up Firebase

1. Create a Firebase project in the Firebase console.
2. Enable Firebase Authentication, Firestore, and Storage.
3. Download the `google-services.json` (for Android) and `GoogleService-Info.plist` (for iOS), and place them in the respective directories:
    - **Android:** `android/app`
    - **iOS:** `ios/Runner`

### Add Jitsi Meet API

Make sure the Jitsi Meet package is added in your `pubspec.yaml`:

```yaml
jitsi_meet: ^4.0.0
```

Run `flutter pub get` to install it.

### Configure API keys (if needed)

Update any necessary API keys (e.g., for Firebase or Jitsi Meet) in the configuration files.

### Run the app
To launch the app in debug mode, run the following command:

```bash
flutter run
```

Test on Emulator or Physical Device
Make sure to have an Android/iOS emulator or a physical device connected to test the app.

