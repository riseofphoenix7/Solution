package com.example.mitra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
