import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class SMEListScreen extends StatelessWidget {
  final String smeId;

  const SMEListScreen({super.key, required this.smeId}); // SME user ID
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marketplace'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('smes')
            .doc(smeId)
            .collection('Listings')
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) return const CircularProgressIndicator();
          final listings = snapshot.data!.docs;
          return ListView.builder(
            itemCount: listings.length,
            itemBuilder: (context, index) {
              final listing = listings[index];
              return ListingCard(listing: listing);
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => AddListingScreen(smeId: smeId)),
          );
        },
        backgroundColor: Colors.teal,
        child: Icon(Icons.add),
      ),
    );
  }
}

class ListingCard extends StatelessWidget {
  final QueryDocumentSnapshot listing;

  const ListingCard({super.key, required this.listing});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(10.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      elevation: 5,
      child: Column(
        children: [
          Image.network(listing['images'][0], fit: BoxFit.cover),
          ListTile(
            title: Text(listing['title'],
                style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('\$${listing['price']}',
                style: const TextStyle(color: Colors.teal)),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(listing['description']),
          ),
        ],
      ),
    );
  }
}

class AddListingScreen extends StatefulWidget {
  final String smeId;
  const AddListingScreen({super.key, required this.smeId});

  @override
  _AddListingScreenState createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _formKey = GlobalKey<FormState>();
  String _title = '';
  String _description = '';
  double _price = 0;
  final List<File> _images = [];

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _images.add(File(pickedFile.path));
      });
    }
  }

  Future<void> _saveListing() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final imageUrls =
          await Future.wait(_images.map((image) => uploadImage(image)));

      FirebaseFirestore.instance
          .collection('SMEs')
          .doc(widget.smeId)
          .collection('Listings')
          .add({
        'title': _title,
        'description': _description,
        'price': _price,
        'currency': 'USD',
        'images': imageUrls,
        'quantity': 10,
        'available': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });

      Navigator.pop(context);
    }
  }

  Future<String> uploadImage(File image) async {
    final storageRef = FirebaseStorage.instance
        .ref()
        .child('images/${DateTime.now().millisecondsSinceEpoch}.jpg');
    await storageRef.putFile(image);
    return await storageRef.getDownloadURL();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Listing'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Title'),
                validator: (value) => value!.isEmpty ? 'Enter a title' : null,
                onSaved: (value) => _title = value!,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Description'),
                validator: (value) =>
                    value!.isEmpty ? 'Enter a description' : null,
                onSaved: (value) => _description = value!,
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Price'),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Enter a price' : null,
                onSaved: (value) => _price = double.parse(value!),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                icon: const Icon(Icons.add_a_photo),
                label: const Text('Add Image'),
                onPressed: _pickImage,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveListing,
                child: const Text('Save Listing'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
