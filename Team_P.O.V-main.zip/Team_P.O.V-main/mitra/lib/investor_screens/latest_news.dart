import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  List<dynamic> _news = [];

  @override
  void initState() {
    super.initState();
    fetchNews();
  }

  Future<void> fetchNews() async {
    const apiKey =
        'pub_56509e1267c6068124d3954f05df55b4fdf99'; // Replace with your actual API key
    final url =
        'https://newsdata.io/api/1/news?apikey=$apiKey&country=in&category=business&language=en';

    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      setState(() {
        _news = data['results'] ?? [];
        print(data['results']);
      });
    } else {
      throw Exception('Failed to load news');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Business News in India')),
      body: ListView.builder(
        itemCount: _news.length,
        itemBuilder: (context, index) {
          return NewsCard(article: _news[index]);
        },
      ),
    );
  }
}

class NewsCard extends StatelessWidget {
  final dynamic article;

  const NewsCard({super.key, required this.article});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8.0),
      child: Column(
        children: <Widget>[
          if (article['image_url'] != null)
            Image.network(article['image_url'])
          else
            const SizedBox.shrink(),
          ListTile(
            title: Text(article['title'] ?? 'No title available'),
            subtitle:
                Text(article['description'] ?? 'No description available'),
          ),
        ],
      ),
    );
  }
}
