import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Investor Feed',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: Colors.grey[100],
      ),
      home: InvestorFeed(),
    );
  }
}

class InvestorFeed extends StatelessWidget {
  const InvestorFeed({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Investor Feed',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.indigo[700],
        elevation: 0,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('investors').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No Investors found'));
          }
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var investor =
                  snapshot.data!.docs[index].data() as Map<String, dynamic>;
              return InvestorCard(investor: investor);
            },
          );
        },
      ),
    );
  }
}

class InvestorCard extends StatelessWidget {
  final Map<String, dynamic> investor;

  const InvestorCard({super.key, required this.investor});

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => DetailedInvestorView(investor: investor)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundImage: NetworkImage(investor['profileUrl'] ??
                        'https://via.placeholder.com/60'),
                    radius: 30,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          investor['investorName'] ?? 'Investor Name',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        Wrap(
                          spacing: 4,
                          children: (investor['preferredSectors']
                                      as List<dynamic>? ??
                                  [])
                              .take(2)
                              .map((sector) => Chip(
                                    label: Text(sector,
                                        style: const TextStyle(fontSize: 12)),
                                    backgroundColor: Colors.indigo[50],
                                  ))
                              .toList(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                investor['description'] ?? 'No description available',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Investment Range: ₹${formatter.format((investor['minimumTicketSize'] ?? 0) / 100000)}L - ₹${formatter.format((investor['maximumTicketSize'] ?? 0) / 100000)}L',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildIconButton(Icons.email, 'Email',
                      () => _launchEmail(investor['email'])),
                  _buildIconButton(Icons.web, 'Website',
                      () => _launchWebsite(investor['website'])),
                  _buildIconButton(Icons.business, 'Portfolio',
                      () => _showPortfolio(context, investor)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton(IconData icon, String label, VoidCallback onPressed) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: Colors.indigo[700]),
          onPressed: onPressed,
        ),
        Text(label, style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  void _launchEmail(String? email) async {
    if (email != null) {
      final Uri emailLaunchUri = Uri(scheme: 'mailto', path: email);
      if (await canLaunch(emailLaunchUri.toString())) {
        await launch(emailLaunchUri.toString());
      }
    }
  }

  void _launchWebsite(String? website) async {
    if (website != null && await canLaunch(website)) {
      await launch(website);
    }
  }

  void _showPortfolio(BuildContext context, Map<String, dynamic> investor) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PortfolioView(investorId: investor['id']),
      ),
    );
  }
}

class DetailedInvestorView extends StatelessWidget {
  final Map<String, dynamic> investor;

  const DetailedInvestorView({super.key, required this.investor});

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat("#,##0.00", "en_IN");
    return Scaffold(
      appBar: AppBar(
        title: Text(investor['investorName'] ?? 'Investor Details'),
        backgroundColor: Colors.indigo[700],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: CircleAvatar(
                backgroundImage: NetworkImage(investor['profileUrl'] ??
                    'https://via.placeholder.com/120'),
                radius: 60,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              investor['investorName'] ?? 'Investor Name',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            _buildInfoCard('Contact Information', [
              _buildInfoRow('Email', investor['email'] ?? 'N/A'),
              _buildInfoRow('Website', investor['website'] ?? 'N/A'),
            ]),
            const SizedBox(height: 16),
            _buildInfoCard('Investment Criteria', [
              _buildInfoRow('Minimum Investment',
                  '₹${formatter.format((investor['minimumTicketSize'] ?? 0) / 100000)} Lakhs'),
              _buildInfoRow('Maximum Investment',
                  '₹${formatter.format((investor['maximumTicketSize'] ?? 0) / 100000)} Lakhs'),
              _buildInfoRow(
                  'Expected ROI', '${investor['expectedROI'] ?? 'N/A'}%'),
            ]),
            const SizedBox(height: 16),
            _buildInfoCard('Investment Preferences', [
              const Text('Preferred Sectors:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: (investor['preferredSectors'] as List<dynamic>? ?? [])
                    .map((sector) => Chip(
                          label: Text(sector),
                          backgroundColor: Colors.indigo[50],
                        ))
                    .toList(),
              ),
              const SizedBox(height: 16),
              const Text('Preferred Stages:',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: (investor['preferredStages'] as List<dynamic>? ?? [])
                    .map((stage) => Chip(
                          label: Text(stage),
                          backgroundColor: Colors.indigo[50],
                        ))
                    .toList(),
              ),
            ]),
            const SizedBox(height: 24),
            const Text('Investment Thesis',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(investor['investmentThesis'] ??
                'No investment thesis available.'),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      PortfolioView(investorId: investor['id']),
                ),
              ),
              style: ElevatedButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
              child: Text('View Portfolio Companies'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.indigo[700])),
            const SizedBox(height: 8),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(value, style: TextStyle(color: Colors.grey[800])),
        ],
      ),
    );
  }
}

class PortfolioView extends StatelessWidget {
  final String investorId;

  const PortfolioView({super.key, required this.investorId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Portfolio Companies'),
        backgroundColor: Colors.indigo[700],
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('investors')
            .doc(investorId)
            .collection('portfolio')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No portfolio companies found'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var company =
                  snapshot.data!.docs[index].data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundImage: NetworkImage(
                        company['logoUrl'] ?? 'https://via.placeholder.com/40'),
                  ),
                  title: Text(company['name'] ?? ''),
                  subtitle: Text(company['sector'] ?? ''),
                  trailing: Text(
                    '₹${NumberFormat("#,##0.00", "en_IN").format((company['investmentAmount'] ?? 0) / 100000)}L',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
