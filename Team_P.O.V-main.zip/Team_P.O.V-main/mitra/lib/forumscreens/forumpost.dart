import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PostCard extends StatefulWidget {
  final String title;
  final String content;
  final String investorId;
  final Timestamp timestamp;
  final String postId; // Pass the post ID for updating likes

  const PostCard({
    super.key,
    required this.title,
    required this.content,
    required this.investorId,
    required this.timestamp,
    required this.postId, // Include postId in the constructor
  });

  @override
  _PostCardState createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  int likesCount = 0; // Initialize likes count
  bool hasLiked = false; // Track if the user has liked the post
  String userType = ''; // Store the type of the user

  @override
  void initState() {
    super.initState();
    _fetchLikesCount();
  }

  Future<void> _fetchLikesCount() async {
    // Fetch the current likes count and liked users for the post
    DocumentSnapshot doc = await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postId)
        .get();
    if (doc.exists) {
      setState(() {
        likesCount = doc['likes'] ?? 0; // Update the likes count
        hasLiked = (doc['likedBy'] as List<dynamic>?)
                ?.contains(FirebaseAuth.instance.currentUser?.uid) ??
            false; // Check if the current user has liked the post
      });
    }

    // Fetch the user type from the 'users' collection
    DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.investorId)
        .get();
    if (userDoc.exists) {
      setState(() {
        userType =
            userDoc['userType'] ?? ''; // Update userType based on document data
      });
    }
  }

  Future<void> _likePost() async {
    final userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null || hasLiked) {
      return; // Exit if user is not logged in or has already liked the post
    }

    // Increment the likes count in Firestore and add the user to the likedBy list
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(widget.postId)
        .update({
      'likes': FieldValue.increment(1), // Increment likes by 1
      'likedBy': FieldValue.arrayUnion([userId]), // Add userId to likedBy
    });

    // Update the local likes count and hasLiked state
    setState(() {
      likesCount += 1;
      hasLiked = true; // Mark as liked
    });
  }

  Color _getUserTypeColor(String userType) {
    switch (userType) {
      case 'student':
        return Colors.green; // Green for students
      case 'sme':
        return Colors.orange; // Orange for SMEs
      case 'investor':
        return Colors.blue; // Blue for investors
      default:
        return Colors.grey; // Default color if no match
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String?>(
      future: _getUserName(widget.investorId),
      builder: (context, investorSnapshot) {
        String investorName = investorSnapshot.data ?? 'Unknown Investor';

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // User profile at the top
                InkWell(
                  onTap: () {
                    // Add functionality here for navigating to the profile or investor details
                  },
                  child: Row(
                    children: [
                      const CircleAvatar(
                        radius: 16,
                        backgroundColor: Colors.blue,
                        child: Icon(
                          Icons.person,
                          color: Colors.white,
                        ), // Profile icon background color
                      ),
                      const SizedBox(width: 4),
                      Text(
                        investorName,
                        style:
                            const TextStyle(fontSize: 14, color: Colors.grey),
                      ),
                      const SizedBox(width: 4),
                      // User type tag
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _getUserTypeColor(userType),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          userType.toUpperCase(), // Display the user type
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                // Title and content
                Text(
                  widget.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                  maxLines: 2, // Set a maximum number of lines for the title
                  overflow:
                      TextOverflow.ellipsis, // Handle overflow with ellipsis
                ),
                const SizedBox(height: 8),
                Text(
                  widget.content,
                  style: const TextStyle(fontSize: 16),
                  maxLines: 3, // Set a maximum number of lines for the content
                  overflow:
                      TextOverflow.ellipsis, // Handle overflow with ellipsis
                ),
                const SizedBox(height: 8),
                // Likes and Like icon
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '$likesCount Likes', // Display the current likes count
                      style: const TextStyle(fontSize: 14, color: Colors.grey),
                    ),
                    IconButton(
                      icon: Icon(
                        hasLiked ? Icons.thumb_up : Icons.thumb_up_off_alt,
                        color: hasLiked ? Colors.blue : Colors.grey,
                      ),
                      onPressed:
                          _likePost, // Call likePost function on button press
                      tooltip: 'Like', // Tooltip for accessibility
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                // Timestamp at the bottom
                Text(
                  'Posted on: ${DateTime.fromMillisecondsSinceEpoch(widget.timestamp.millisecondsSinceEpoch).toLocal()}',
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<String?> _getUserName(String investorId) async {
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(investorId)
        .get();
    return doc.exists
        ? doc['name']
        : null; // Return the name if the document exists
  }
}
