class Question {
  final String question;
  final List<String> options;

  Question({required this.question, required this.options});
}

final List<Question> investorQuestions = [
  Question(
    question:
        'What type of businesses are you most interested in investing in?',
    options: [
      'Tech Startups',
      'Agriculture',
      'Manufacturing',
      'Retail',
      'Other'
    ],
  ),
  Question(
    question: 'What stage of businesses do you prefer to invest in?',
    options: ['Seed Stage', 'Growth Stage', 'Late Stage', 'Mature Stage'],
  ),
  Question(
    question: 'What is your typical investment size?',
    options: ['< \$50K', '\$50K - \$250K', '\$250K - \$1M', '> \$1M'],
  ),
  Question(
    question: 'What is your preferred investment timeline?',
    options: ['< 1 Year', '1-3 Years', '3-5 Years', '5+ Years'],
  ),
  Question(
    question: 'Which sectors do you have the most experience in?',
    options: [
      'Technology',
      'Healthcare',
      'Real Estate',
      'Energy',
      'Finance',
      'Other'
    ],
  ),
  Question(
    question: 'Are you open to investing in rural businesses?',
    options: ['Yes', 'No', 'Depends on the Opportunity'],
  ),
  Question(
    question: 'What are your primary reasons for joining this platform?',
    options: [
      'Expand Portfolio',
      'Support Small Businesses',
      'Explore New Markets',
      'Other'
    ],
  ),
  Question(
    question: 'How do you prefer to connect with SMEs?',
    options: [
      'Direct Messaging',
      'Video Calls',
      'In-person Meetings',
      'Through Pitch Events'
    ],
  ),
  Question(
    question: 'What is your risk tolerance for investments?',
    options: ['Low', 'Moderate', 'High'],
  ),
  Question(
    question: 'What geographical regions are you interested in investing in?',
    options: ['Local', 'National', 'International', 'Rural Areas Only'],
  ),
  Question(
    question: 'How do you prefer to assess investment opportunities?',
    options: [
      'Business Plans',
      'Financial Reports',
      'Pitch Decks',
      'Face-to-face Meetings'
    ],
  ),
  Question(
    question: 'What type of return on investment (ROI) are you expecting?',
    options: ['5-10%', '10-20%', '20%+', 'Depends on Opportunity'],
  ),
];

final List<Question> businessOwnerQuestions = [
  Question(
    question: 'What type of business do you own?',
    options: [
      'Tech Startup',
      'Agriculture',
      'Manufacturing',
      'Retail',
      'Other'
    ],
  ),
  Question(
    question: 'What stage is your business in?',
    options: ['Idea Stage', 'Startup Stage', 'Growth Stage', 'Mature Stage'],
  ),
  Question(
    question: 'What is your current funding status?',
    options: [
      'Bootstrapped',
      'Seed Funding',
      'Series A',
      'Series B',
      'Series C+'
    ],
  ),
  Question(
    question: 'What is your primary reason for seeking funding?',
    options: ['Expand Operations', 'Product Development', 'Marketing', 'Other'],
  ),
  Question(
    question: 'What is your preferred investment timeline?',
    options: ['< 1 Year', '1-3 Years', '3-5 Years', '5+ Years'],
  ),
  Question(
    question: 'What is your typical funding size?',
    options: ['< \$50K', '\$50K - \$250K', '\$250K - \$1M', '> \$1M'],
  ),
  Question(
    question: 'What geographical regions are you interested in expanding to?',
    options: ['Local', 'National', 'International', 'Rural Areas Only'],
  ),
  Question(
    question: 'What are your primary reasons for joining this platform?',
    options: ['Access to Capital', 'Networking', 'Mentorship', 'Other'],
  ),
  Question(
    question: 'How do you prefer to connect with investors?',
    options: [
      'Direct Messaging',
      'Video Calls',
      'In-person Meetings',
      'Through Pitch Events'
    ],
  ),
  Question(
    question: 'What is your risk tolerance for investors?',
    options: ['Low', 'Moderate', 'High'],
  ),
  Question(
    question: 'What type of investors are you looking to connect with?',
    options: [
      'Angel Investors',
      'Venture Capitalists',
      'Private Equity Firms',
      'Other'
    ],
  ),
  Question(
    question: 'What type of return on investment (ROI) are you offering?',
    options: ['5-10%', '10-20%', '20%+', 'Depends on Opportunity'],
  ),
];
