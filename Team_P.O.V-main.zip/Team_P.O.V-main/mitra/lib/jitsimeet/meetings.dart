import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mitra/jitsimeet/meetscheduler.dart';

class MeetingsPage extends StatefulWidget {
  const MeetingsPage({super.key});

  @override
  _MeetingsPageState createState() => _MeetingsPageState();
}

class _MeetingsPageState extends State<MeetingsPage> {
  String currentUserId = '';

  @override
  void initState() {
    super.initState();
    _getCurrentUserId();
  }

  Future<void> _getCurrentUserId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        currentUserId = user.uid;
      });
      print('Current User ID: $currentUserId'); // Debugging line
    }
  }

  Stream<QuerySnapshot> _getPendingMeetings() {
    return FirebaseFirestore.instance
        .collection('meetings')
        .where('targetUser', isEqualTo: currentUserId)
        .where('confirmed', isEqualTo: false)
        .snapshots();
  }

  Stream<QuerySnapshot> _getConfirmedMeetings() {
    return FirebaseFirestore.instance
        .collection('meetings')
        .where('targetUser', isEqualTo: currentUserId)
        .where('confirmed', isEqualTo: true)
        .snapshots();
  }

  Future<void> _acceptMeeting(String meetingId) async {
    await FirebaseFirestore.instance
        .collection('meetings')
        .doc(meetingId)
        .update({'confirmed': true});
  }

  Future<void> _rejectMeeting(String meetingId) async {
    await FirebaseFirestore.instance
        .collection('meetings')
        .doc(meetingId)
        .delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Meetings'),
      ),
      body: Column(
        children: [
          // Pending meeting requests

          // Accepted meetings
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _getConfirmedMeetings(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final confirmedMeetings = snapshot.data!.docs;
                if (confirmedMeetings.isEmpty) {
                  return const Center(child: Text('No confirmed meetings'));
                }

                return ListView.builder(
                  itemCount: confirmedMeetings.length,
                  itemBuilder: (context, index) {
                    DocumentSnapshot meeting = confirmedMeetings[index];
                    DateTime meetingTime = DateTime.parse(meeting['time']);
                    return ListTile(
                      onTap: () {
                        // Push to JitsiMeetPage
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                JitsiMeetScreen(title: meeting.id),
                          ),
                        );
                      },
                      title: Text('Meeting with ${meeting['initiator']}'),
                      subtitle: Text('Date: ${meetingTime.toLocal()}'),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
