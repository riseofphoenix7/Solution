import 'package:flutter/material.dart';
import 'forumpage.dart';

class ForumTopicsPage extends StatefulWidget {
  const ForumTopicsPage({super.key});

  @override
  _ForumTopicsPageState createState() => _ForumTopicsPageState();
}

class _ForumTopicsPageState extends State<ForumTopicsPage> {
  final List<Map<String, dynamic>> investmentTopics = [
    {
      'name': 'Stocks',
      'icon': Icons.trending_up,
      'color': Colors.blue,
      'users': ['Alice', 'Bob', 'Charlie']
    },
    {
      'name': 'Bonds',
      'icon': Icons.attach_money,
      'color': Colors.green,
      'users': ['David', 'Eva']
    },
    {
      'name': 'Mutual Funds',
      'icon': Icons.group,
      'color': Colors.orange,
      'users': ['Frank', 'Grace', 'Hannah']
    },
    {
      'name': 'Real Estate',
      'icon': Icons.home,
      'color': Colors.brown,
      'users': ['Ivy', 'Jack']
    },
    {
      'name': 'Cryptocurrency',
      'icon': Icons.monetization_on,
      'color': Colors.purple,
      'users': ['Kevin', 'Lily', 'Mason']
    },
    {
      'name': 'Exchange-Traded Funds (ETFs)',
      'icon': Icons.show_chart,
      'color': Colors.teal,
      'users': ['Nina', 'Oscar']
    },
    {
      'name': 'Retirement Accounts',
      'icon': Icons.access_time,
      'color': Colors.red,
      'users': ['Peter', 'Quinn', 'Rose']
    },
    {
      'name': 'Robo-Advisors',
      'icon': Icons.computer,
      'color': Colors.yellow,
      'users': ['Sam', 'Tina']
    },
    {
      'name': 'Commodities',
      'icon': Icons.storage,
      'color': Colors.cyan,
      'users': ['Uma', 'Victor', 'Wendy']
    },
    {
      'name': 'Forex Trading',
      'icon': Icons.trending_down,
      'color': Colors.deepOrange,
      'users': ['Xander', 'Yara', 'Zane']
    },
  ];

  List<Map<String, dynamic>> filteredTopics = [];
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    filteredTopics = investmentTopics; // Initialize with all topics
  }

  void filterSearchResults(String query) {
    List<Map<String, dynamic>> results = [];
    if (query.isEmpty) {
      results = investmentTopics;
    } else {
      results = investmentTopics
          .where((topic) =>
              topic['name'].toLowerCase().contains(query.toLowerCase()))
          .toList();
    }
    setState(() {
      filteredTopics = results;
    });
  }

  void clearSearch() {
    searchController.clear();
    filterSearchResults('');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Investment Communities'),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue, Colors.purple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              onChanged: (value) {
                filterSearchResults(value);
              },
              decoration: InputDecoration(
                labelText: 'Search',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: clearSearch,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
          ),
          Expanded(
            child: filteredTopics.isEmpty
                ? const Center(
                    child: Text('No communities found'),
                  )
                : ListView.builder(
                    itemCount: filteredTopics.length,
                    itemBuilder: (context, index) {
                      final topic = filteredTopics[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 10.0),
                        elevation: 4,
                        color: topic['color']
                            .withOpacity(0.2), // Set background color
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: ListTile(
                          leading: Icon(
                            topic['icon'],
                            color: topic['color'],
                          ),
                          title: Text(
                            topic['name'],
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                            'Participants: ${topic['users'].join(', ')}',
                            style: const TextStyle(color: Colors.black54),
                          ),
                          onTap: () {
                            // Navigate to the Forums page, passing the topic as the topicId
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    Forums(topicId: topic['name']),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
