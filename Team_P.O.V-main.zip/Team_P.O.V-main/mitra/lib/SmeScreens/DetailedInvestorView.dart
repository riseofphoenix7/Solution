import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class DetailedInvestorView extends StatelessWidget {
  final String investorId;

  const DetailedInvestorView({Key? key, required this.investorId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Investor Details'),
        backgroundColor: Colors.indigo[700],
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance
            .collection('investors')
            .doc(investorId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: Text('Investor not found'));
          }

          final investor = snapshot.data!.data() as Map<String, dynamic>;
          final formatter = NumberFormat("#,##0.00", "en_US");

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: CircleAvatar(
                    backgroundImage: NetworkImage(investor['profileImageUrl'] ??
                        'https://via.placeholder.com/120'),
                    radius: 60,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  investor['name'] ?? 'Investor Name',
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  investor['bio'] ?? 'No bio available',
                  style: const TextStyle(fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                _buildInfoCard('Contact Information', [
                  _buildInfoRow('Email', investor['email'] ?? 'N/A'),
                  _buildInfoRow('Website', investor['website'] ?? 'N/A'),
                ]),
                const SizedBox(height: 16),
                _buildInfoCard('Investment Criteria', [
                  _buildInfoRow('Minimum Investment',
                      '₹${formatter.format((investor['minimumTicketSize'] ?? 0) / 100000)} Lakhs'),
                  _buildInfoRow('Maximum Investment',
                      '₹${formatter.format((investor['maximumTicketSize'] ?? 0) / 100000)} Lakhs'),
                  _buildInfoRow(
                      'Expected ROI', '${investor['expectedROI'] ?? 'N/A'}%'),
                ]),
                const SizedBox(height: 16),
                _buildInfoCard('Investment Preferences', [
                  const Text('Preferred Sectors:',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children:
                        (investor['preferredSectors'] as List<dynamic>? ?? [])
                            .map((sector) => Chip(
                                  label: Text(sector),
                                  backgroundColor: Colors.indigo[50],
                                ))
                            .toList(),
                  ),
                  const SizedBox(height: 16),
                  const Text('Preferred Stages:',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children:
                        (investor['preferredStages'] as List<dynamic>? ?? [])
                            .map((stage) => Chip(
                                  label: Text(stage),
                                  backgroundColor: Colors.indigo[50],
                                ))
                            .toList(),
                  ),
                ]),
                const SizedBox(height: 24),
                const Text('Investment Thesis',
                    style:
                        TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(investor['investmentThesis'] ??
                    'No investment thesis available.'),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoCard(String title, List<Widget> children) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(value),
        ],
      ),
    );
  }
}
