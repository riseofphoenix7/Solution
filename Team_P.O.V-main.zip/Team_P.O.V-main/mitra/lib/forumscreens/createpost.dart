import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CreatePost extends StatefulWidget {
  final List<String> topics; // List of topics for dropdown selection

  const CreatePost({super.key, required this.topics});

  @override
  _CreatePostState createState() => _CreatePostState();
}

class _CreatePostState extends State<CreatePost> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  String? _selectedTopic;

  Future<void> _submitPost() async {
    final String? currentUserId = FirebaseAuth.instance.currentUser?.uid;
    if (currentUserId == null) return;

    if (_titleController.text.isNotEmpty &&
        _contentController.text.isNotEmpty &&
        _selectedTopic != null) {
      // Create a new post in Firestore
      await FirebaseFirestore.instance.collection('posts').add({
        'title': _titleController.text,
        'content': _contentController.text,
        'investorId': currentUserId,
        'timestamp': FieldValue.serverTimestamp(),
        'topicId': _selectedTopic,
        'likes': 0,
        'likedBy': [] // Inclsude the selected topic ID
      });

      // Clear the fields after submission
      _titleController.clear();
      _contentController.clear();
      setState(() {
        _selectedTopic = null; // Reset the selected topic
      });

      Navigator.of(context).pop(); // Close the dialog after submission
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Create a New Post'),
      content: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: _contentController,
              decoration: const InputDecoration(labelText: 'Content'),
              maxLines: 5,
            ),
            DropdownButton<String>(
              value: _selectedTopic,
              hint: const Text('Select a Topic'),
              onChanged: (String? newValue) {
                setState(() {
                  _selectedTopic = newValue; // Update the selected topic
                });
              },
              items:
                  widget.topics.map<DropdownMenuItem<String>>((String topic) {
                return DropdownMenuItem<String>(
                  value: topic,
                  child: Text(topic),
                );
              }).toList(),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(), // Close the dialog
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _submitPost, // Call the submitPost method
          child: const Text('Submit'),
        ),
      ],
    );
  }
}
